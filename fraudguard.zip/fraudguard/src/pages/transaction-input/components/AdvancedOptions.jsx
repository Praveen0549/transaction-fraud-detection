import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const AdvancedOptions = ({ options, onOptionsChange }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const detectionModels = [
    { value: 'standard', label: 'Standard Model (Recommended)' },
    { value: 'enhanced', label: 'Enhanced ML Model' },
    { value: 'deep_learning', label: 'Deep Learning Model' },
    { value: 'ensemble', label: 'Ensemble Model' },
    { value: 'custom', label: 'Custom Model' }
  ];

  const riskThresholds = [
    { value: 'conservative', label: 'Conservative (30% threshold)' },
    { value: 'balanced', label: 'Balanced (50% threshold)' },
    { value: 'aggressive', label: 'Aggressive (70% threshold)' },
    { value: 'custom', label: 'Custom Threshold' }
  ];

  const analysisDepths = [
    { value: 'basic', label: 'Basic Analysis' },
    { value: 'standard', label: 'Standard Analysis' },
    { value: 'comprehensive', label: 'Comprehensive Analysis' },
    { value: 'deep', label: 'Deep Analysis' }
  ];

  const handleOptionChange = (key, value) => {
    const updatedOptions = { ...options, [key]: value };
    onOptionsChange(updatedOptions);
  };

  return (
    <div className="bg-card rounded-lg shadow-card border border-border p-6">
      <div 
        className="flex items-center justify-between cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-10 h-10 bg-secondary/10 rounded-lg">
            <Icon name="Settings" size={20} color="var(--color-secondary)" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-text-primary">Advanced Options</h2>
            <p className="text-sm text-text-secondary">Customize fraud detection parameters</p>
          </div>
        </div>
        
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          color="var(--color-text-secondary)" 
        />
      </div>
      {isExpanded && (
        <div className="mt-6 space-y-6">
          {/* Detection Model Selection */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-text-primary flex items-center space-x-2">
              <Icon name="Brain" size={18} color="var(--color-primary)" />
              <span>Detection Model</span>
            </h3>
            
            <Select
              label="AI Model Selection"
              description="Choose the fraud detection model for analysis"
              placeholder="Select detection model"
              options={detectionModels}
              value={options?.detectionModel || 'standard'}
              onChange={(value) => handleOptionChange('detectionModel', value)}
            />

            {options?.detectionModel === 'custom' && (
              <Input
                label="Custom Model Endpoint"
                type="text"
                placeholder="Enter custom model API endpoint"
                value={options?.customModelEndpoint || ''}
                onChange={(e) => handleOptionChange('customModelEndpoint', e?.target?.value)}
              />
            )}
          </div>

          {/* Risk Threshold Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-text-primary flex items-center space-x-2">
              <Icon name="Target" size={18} color="var(--color-warning)" />
              <span>Risk Threshold</span>
            </h3>
            
            <Select
              label="Risk Sensitivity"
              description="Set the threshold for flagging transactions as fraudulent"
              placeholder="Select risk threshold"
              options={riskThresholds}
              value={options?.riskThreshold || 'balanced'}
              onChange={(value) => handleOptionChange('riskThreshold', value)}
            />

            {options?.riskThreshold === 'custom' && (
              <Input
                label="Custom Threshold (%)"
                type="number"
                placeholder="Enter threshold percentage"
                value={options?.customThreshold || ''}
                onChange={(e) => handleOptionChange('customThreshold', e?.target?.value)}
                min="1"
                max="99"
              />
            )}
          </div>

          {/* Analysis Depth */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-text-primary flex items-center space-x-2">
              <Icon name="Layers" size={18} color="var(--color-accent)" />
              <span>Analysis Depth</span>
            </h3>
            
            <Select
              label="Analysis Complexity"
              description="Choose the depth of fraud analysis to perform"
              placeholder="Select analysis depth"
              options={analysisDepths}
              value={options?.analysisDepth || 'standard'}
              onChange={(value) => handleOptionChange('analysisDepth', value)}
            />
          </div>

          {/* Feature Toggles */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-text-primary flex items-center space-x-2">
              <Icon name="Toggles" size={18} color="var(--color-success)" />
              <span>Analysis Features</span>
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Checkbox
                label="Behavioral Analysis"
                description="Analyze user behavior patterns"
                checked={options?.behavioralAnalysis || false}
                onChange={(e) => handleOptionChange('behavioralAnalysis', e?.target?.checked)}
              />
              
              <Checkbox
                label="Geolocation Verification"
                description="Verify transaction location"
                checked={options?.geolocationVerification || false}
                onChange={(e) => handleOptionChange('geolocationVerification', e?.target?.checked)}
              />
              
              <Checkbox
                label="Time Pattern Analysis"
                description="Analyze transaction timing patterns"
                checked={options?.timePatternAnalysis || false}
                onChange={(e) => handleOptionChange('timePatternAnalysis', e?.target?.checked)}
              />
              
              <Checkbox
                label="Network Analysis"
                description="Analyze transaction network connections"
                checked={options?.networkAnalysis || false}
                onChange={(e) => handleOptionChange('networkAnalysis', e?.target?.checked)}
              />
              
              <Checkbox
                label="Historical Comparison"
                description="Compare with historical data"
                checked={options?.historicalComparison || false}
                onChange={(e) => handleOptionChange('historicalComparison', e?.target?.checked)}
              />
              
              <Checkbox
                label="Real-time Monitoring"
                description="Enable real-time fraud monitoring"
                checked={options?.realTimeMonitoring || false}
                onChange={(e) => handleOptionChange('realTimeMonitoring', e?.target?.checked)}
              />
            </div>
          </div>

          {/* Processing Options */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-text-primary flex items-center space-x-2">
              <Icon name="Zap" size={18} color="var(--color-error)" />
              <span>Processing Options</span>
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="Processing Timeout (seconds)"
                type="number"
                placeholder="30"
                value={options?.processingTimeout || '30'}
                onChange={(e) => handleOptionChange('processingTimeout', e?.target?.value)}
                min="5"
                max="300"
              />
              
              <Select
                label="Result Format"
                placeholder="Select format"
                options={[
                  { value: 'detailed', label: 'Detailed Report' },
                  { value: 'summary', label: 'Summary Only' },
                  { value: 'json', label: 'JSON Format' },
                  { value: 'csv', label: 'CSV Export' }
                ]}
                value={options?.resultFormat || 'detailed'}
                onChange={(value) => handleOptionChange('resultFormat', value)}
              />
            </div>
          </div>

          {/* Notification Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-text-primary flex items-center space-x-2">
              <Icon name="Bell" size={18} color="var(--color-primary)" />
              <span>Notification Settings</span>
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Checkbox
                label="Email Alerts"
                description="Send email for high-risk transactions"
                checked={options?.emailAlerts || false}
                onChange={(e) => handleOptionChange('emailAlerts', e?.target?.checked)}
              />
              
              <Checkbox
                label="SMS Notifications"
                description="Send SMS for critical alerts"
                checked={options?.smsNotifications || false}
                onChange={(e) => handleOptionChange('smsNotifications', e?.target?.checked)}
              />
              
              <Checkbox
                label="Dashboard Alerts"
                description="Show alerts on dashboard"
                checked={options?.dashboardAlerts || true}
                onChange={(e) => handleOptionChange('dashboardAlerts', e?.target?.checked)}
              />
              
              <Checkbox
                label="API Webhooks"
                description="Send results to webhook endpoint"
                checked={options?.apiWebhooks || false}
                onChange={(e) => handleOptionChange('apiWebhooks', e?.target?.checked)}
              />
            </div>

            {options?.apiWebhooks && (
              <Input
                label="Webhook URL"
                type="url"
                placeholder="https://your-api.com/webhook"
                value={options?.webhookUrl || ''}
                onChange={(e) => handleOptionChange('webhookUrl', e?.target?.value)}
              />
            )}
          </div>

          {/* Reset to Defaults */}
          <div className="pt-4 border-t border-border">
            <button
              type="button"
              onClick={() => onOptionsChange({})}
              className="text-sm text-text-secondary hover:text-text-primary transition-micro flex items-center space-x-2"
            >
              <Icon name="RotateCcw" size={16} />
              <span>Reset to Default Settings</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdvancedOptions;