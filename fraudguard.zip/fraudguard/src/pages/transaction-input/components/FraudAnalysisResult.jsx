import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FraudAnalysisResult = ({ result, onReset }) => {
  if (!result) return null;

  const getRiskLevel = (probability) => {
    if (probability >= 0.8) return { level: 'High', color: 'error', bgColor: 'bg-red-50', textColor: 'text-red-700' };
    if (probability >= 0.5) return { level: 'Medium', color: 'warning', bgColor: 'bg-yellow-50', textColor: 'text-yellow-700' };
    return { level: 'Low', color: 'success', bgColor: 'bg-green-50', textColor: 'text-green-700' };
  };

  const risk = getRiskLevel(result?.fraudProbability);

  const riskFactors = [
    {
      factor: 'Transaction Amount',
      score: result?.amountRisk,
      description: result?.amountRisk > 0.7 ? 'Unusually high amount for this account' : 'Amount within normal range'
    },
    {
      factor: 'Time Pattern',
      score: result?.timeRisk,
      description: result?.timeRisk > 0.7 ? 'Transaction at unusual time' : 'Normal transaction timing'
    },
    {
      factor: 'Location Analysis',
      score: result?.locationRisk,
      description: result?.locationRisk > 0.7 ? 'Transaction from unusual location' : 'Location matches user pattern'
    },
    {
      factor: 'Account Behavior',
      score: result?.behaviorRisk,
      description: result?.behaviorRisk > 0.7 ? 'Deviates from normal account behavior' : 'Consistent with account history'
    }
  ];

  const recommendations = result?.fraudProbability >= 0.8 
    ? [
        'Block transaction immediately',
        'Contact account holder for verification',
        'Review recent account activity',
        'Flag account for enhanced monitoring'
      ]
    : result?.fraudProbability >= 0.5
    ? [
        'Request additional authentication',
        'Monitor account for 24 hours',
        'Review transaction pattern',
        'Consider manual review'
      ]
    : [
        'Process transaction normally',
        'Continue standard monitoring',
        'No additional action required'
      ];

  return (
    <div className="space-y-6">
      {/* Main Result Card */}
      <div className={`${risk?.bgColor} rounded-lg border-2 border-${risk?.color} p-6`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className={`flex items-center justify-center w-12 h-12 bg-${risk?.color} rounded-lg`}>
              <Icon 
                name={risk?.level === 'High' ? 'AlertTriangle' : risk?.level === 'Medium' ? 'AlertCircle' : 'CheckCircle'} 
                size={24} 
                color="white" 
              />
            </div>
            <div>
              <h3 className={`text-xl font-semibold ${risk?.textColor}`}>
                {risk?.level} Risk Transaction
              </h3>
              <p className="text-sm text-text-secondary">
                Fraud Probability: {(result?.fraudProbability * 100)?.toFixed(1)}%
              </p>
            </div>
          </div>
          
          <div className="text-right">
            <div className={`text-3xl font-bold ${risk?.textColor}`}>
              {(result?.fraudProbability * 100)?.toFixed(1)}%
            </div>
            <div className="text-sm text-text-secondary">Confidence Score</div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
          <div 
            className={`bg-${risk?.color} h-3 rounded-full transition-all duration-1000`}
            style={{ width: `${result?.fraudProbability * 100}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-sm">
          <span className="text-green-600 font-medium">Safe (0%)</span>
          <span className="text-yellow-600 font-medium">Moderate (50%)</span>
          <span className="text-red-600 font-medium">High Risk (100%)</span>
        </div>
      </div>
      {/* Risk Factors Analysis */}
      <div className="bg-card rounded-lg shadow-card border border-border p-6">
        <h4 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
          <Icon name="BarChart3" size={20} color="var(--color-primary)" />
          <span>Risk Factor Analysis</span>
        </h4>
        
        <div className="space-y-4">
          {riskFactors?.map((factor, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-text-primary">{factor?.factor}</span>
                <span className="text-sm font-semibold text-text-secondary">
                  {(factor?.score * 100)?.toFixed(0)}%
                </span>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all duration-1000 ${
                    factor?.score >= 0.7 ? 'bg-error' : 
                    factor?.score >= 0.4 ? 'bg-warning' : 'bg-success'
                  }`}
                  style={{ width: `${factor?.score * 100}%` }}
                />
              </div>
              
              <p className="text-xs text-text-secondary">{factor?.description}</p>
            </div>
          ))}
        </div>
      </div>
      {/* Recommendations */}
      <div className="bg-card rounded-lg shadow-card border border-border p-6">
        <h4 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
          <Icon name="Lightbulb" size={20} color="var(--color-accent)" />
          <span>Recommended Actions</span>
        </h4>
        
        <div className="space-y-3">
          {recommendations?.map((recommendation, index) => (
            <div key={index} className="flex items-start space-x-3">
              <div className="flex items-center justify-center w-6 h-6 bg-primary/10 rounded-full mt-0.5">
                <span className="text-xs font-semibold text-primary">{index + 1}</span>
              </div>
              <span className="text-sm text-text-primary">{recommendation}</span>
            </div>
          ))}
        </div>
      </div>
      {/* Transaction Summary */}
      <div className="bg-card rounded-lg shadow-card border border-border p-6">
        <h4 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
          <Icon name="FileText" size={20} color="var(--color-secondary)" />
          <span>Transaction Summary</span>
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-text-secondary">Amount:</span>
              <span className="font-medium text-text-primary">${result?.amount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary">Type:</span>
              <span className="font-medium text-text-primary">{result?.type}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary">Location:</span>
              <span className="font-medium text-text-primary">{result?.location}</span>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-text-secondary">Sender:</span>
              <span className="font-medium text-text-primary">{result?.sender}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary">Receiver:</span>
              <span className="font-medium text-text-primary">{result?.receiver}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary">Timestamp:</span>
              <span className="font-medium text-text-primary">{result?.timestamp}</span>
            </div>
          </div>
        </div>
      </div>
      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <Button
          variant="outline"
          size="lg"
          iconName="RotateCcw"
          iconPosition="left"
          onClick={onReset}
        >
          Analyze Another Transaction
        </Button>
        
        <Button
          variant="default"
          size="lg"
          iconName="Save"
          iconPosition="left"
        >
          Save Analysis Report
        </Button>
      </div>
    </div>
  );
};

export default FraudAnalysisResult;