import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const BulkUploadSection = ({ onBulkAnalysis }) => {
  const [uploadStatus, setUploadStatus] = useState('idle'); // idle, uploading, processing, completed, error
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [analysisResults, setAnalysisResults] = useState(null);
  const fileInputRef = useRef(null);

  const handleFileSelect = (event) => {
    const file = event?.target?.files?.[0];
    if (file) {
      if (file?.type !== 'text/csv' && !file?.name?.endsWith('.csv')) {
        alert('Please select a CSV file');
        return;
      }
      
      if (file?.size > 10 * 1024 * 1024) { // 10MB limit
        alert('File size must be less than 10MB');
        return;
      }

      setUploadedFile(file);
      setUploadStatus('idle');
    }
  };

  const simulateUploadProgress = () => {
    setUploadStatus('uploading');
    setUploadProgress(0);
    
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setUploadStatus('processing');
          simulateProcessing();
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const simulateProcessing = () => {
    setTimeout(() => {
      // Mock analysis results
      const mockResults = {
        totalTransactions: 150,
        fraudulentTransactions: 12,
        suspiciousTransactions: 8,
        legitimateTransactions: 130,
        averageRiskScore: 0.23,
        processingTime: '2.3 seconds',
        highRiskTransactions: [
          {
            id: 'TXN001',
            amount: 15000,
            sender: 'John Doe',
            receiver: 'Unknown Account',
            riskScore: 0.95,
            location: 'Unknown Location'
          },
          {
            id: 'TXN045',
            amount: 8500,
            sender: 'Sarah Wilson',
            receiver: 'Offshore Account',
            riskScore: 0.87,
            location: 'International'
          },
          {
            id: 'TXN089',
            amount: 12000,
            sender: 'Mike Johnson',
            receiver: 'Suspicious Entity',
            riskScore: 0.82,
            location: 'High-Risk Zone'
          }
        ]
      };
      
      setAnalysisResults(mockResults);
      setUploadStatus('completed');
      onBulkAnalysis && onBulkAnalysis(mockResults);
    }, 3000);
  };

  const handleUpload = () => {
    if (!uploadedFile) return;
    simulateUploadProgress();
  };

  const handleReset = () => {
    setUploadStatus('idle');
    setUploadProgress(0);
    setUploadedFile(null);
    setAnalysisResults(null);
    if (fileInputRef?.current) {
      fileInputRef.current.value = '';
    }
  };

  const downloadSampleCSV = () => {
    const csvContent = `amount,timestamp,sender_name,sender_account,receiver_name,receiver_account,location,transaction_type,description
1500.00,2024-01-15T10:30:00,John Smith,1234567890,Jane Doe,0987654321,New York NY,upi,Payment for services
2500.00,2024-01-15T14:45:00,Alice Johnson,2345678901,Bob Wilson,1876543210,Los Angeles CA,neft,Monthly rent
750.00,2024-01-15T16:20:00,Charlie Brown,3456789012,Diana Prince,2765432109,Chicago IL,imps,Grocery shopping`;
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL?.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sample_transactions.csv';
    a?.click();
    window.URL?.revokeObjectURL(url);
  };

  return (
    <div className="bg-card rounded-lg shadow-card border border-border p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="flex items-center justify-center w-10 h-10 bg-accent/10 rounded-lg">
          <Icon name="Upload" size={20} color="var(--color-accent)" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-text-primary">Bulk Transaction Analysis</h2>
          <p className="text-sm text-text-secondary">Upload CSV file for batch fraud detection</p>
        </div>
      </div>
      {uploadStatus === 'idle' && !uploadedFile && (
        <div className="space-y-6">
          {/* Upload Area */}
          <div 
            className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-micro cursor-pointer"
            onClick={() => fileInputRef?.current?.click()}
          >
            <Icon name="FileUp" size={48} color="var(--color-text-secondary)" className="mx-auto mb-4" />
            <h3 className="text-lg font-medium text-text-primary mb-2">
              Drop your CSV file here or click to browse
            </h3>
            <p className="text-sm text-text-secondary mb-4">
              Maximum file size: 10MB. Supported format: CSV
            </p>
            <Button variant="outline" size="sm">
              Select File
            </Button>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept=".csv"
            onChange={handleFileSelect}
            className="hidden"
          />

          {/* Sample CSV Download */}
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon name="Download" size={20} color="var(--color-primary)" />
              <div>
                <p className="text-sm font-medium text-text-primary">Need a sample format?</p>
                <p className="text-xs text-text-secondary">Download our CSV template</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              iconName="Download"
              iconPosition="left"
              onClick={downloadSampleCSV}
            >
              Download Sample
            </Button>
          </div>
        </div>
      )}
      {uploadedFile && uploadStatus === 'idle' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon name="FileText" size={20} color="var(--color-success)" />
              <div>
                <p className="text-sm font-medium text-text-primary">{uploadedFile?.name}</p>
                <p className="text-xs text-text-secondary">
                  {(uploadedFile?.size / 1024)?.toFixed(1)} KB
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              iconName="X"
              onClick={handleReset}
            />
          </div>

          <div className="flex space-x-4">
            <Button
              variant="default"
              size="lg"
              iconName="Play"
              iconPosition="left"
              onClick={handleUpload}
              fullWidth
            >
              Start Analysis
            </Button>
          </div>
        </div>
      )}
      {(uploadStatus === 'uploading' || uploadStatus === 'processing') && (
        <div className="space-y-4">
          <div className="flex items-center space-x-3 mb-4">
            <Icon name="FileText" size={20} color="var(--color-primary)" />
            <span className="text-sm font-medium text-text-primary">{uploadedFile?.name}</span>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-text-secondary">
                {uploadStatus === 'uploading' ? 'Uploading...' : 'Processing transactions...'}
              </span>
              <span className="text-text-primary font-medium">
                {uploadStatus === 'uploading' ? `${uploadProgress}%` : 'Analyzing...'}
              </span>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ 
                  width: uploadStatus === 'uploading' ? `${uploadProgress}%` : '100%',
                  animation: uploadStatus === 'processing' ? 'pulse 2s infinite' : 'none'
                }}
              />
            </div>
          </div>

          {uploadStatus === 'processing' && (
            <div className="flex items-center space-x-2 text-sm text-text-secondary">
              <Icon name="Zap" size={16} color="var(--color-accent)" />
              <span>AI models are analyzing transaction patterns...</span>
            </div>
          )}
        </div>
      )}
      {uploadStatus === 'completed' && analysisResults && (
        <div className="space-y-6">
          {/* Summary Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold text-text-primary">{analysisResults?.totalTransactions}</div>
              <div className="text-xs text-text-secondary">Total Transactions</div>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{analysisResults?.fraudulentTransactions}</div>
              <div className="text-xs text-red-600">Fraudulent</div>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">{analysisResults?.suspiciousTransactions}</div>
              <div className="text-xs text-yellow-600">Suspicious</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{analysisResults?.legitimateTransactions}</div>
              <div className="text-xs text-green-600">Legitimate</div>
            </div>
          </div>

          {/* High Risk Transactions */}
          <div>
            <h4 className="text-lg font-semibold text-text-primary mb-4">High Risk Transactions</h4>
            <div className="space-y-3">
              {analysisResults?.highRiskTransactions?.map((transaction, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center justify-center w-8 h-8 bg-red-100 rounded-full">
                      <Icon name="AlertTriangle" size={16} color="var(--color-error)" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-text-primary">{transaction?.id}</p>
                      <p className="text-xs text-text-secondary">
                        ${transaction?.amount?.toLocaleString()} • {transaction?.sender} → {transaction?.receiver}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-red-600">
                      {(transaction?.riskScore * 100)?.toFixed(0)}%
                    </div>
                    <div className="text-xs text-red-500">Risk Score</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              variant="outline"
              size="lg"
              iconName="Download"
              iconPosition="left"
              fullWidth
            >
              Download Report
            </Button>
            <Button
              variant="ghost"
              size="lg"
              iconName="RotateCcw"
              iconPosition="left"
              onClick={handleReset}
              fullWidth
            >
              Upload Another File
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default BulkUploadSection;