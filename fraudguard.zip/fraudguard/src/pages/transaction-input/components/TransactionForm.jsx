import React, { useState, useEffect } from 'react';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const TransactionForm = ({ onSubmit, isAnalyzing }) => {
  const [formData, setFormData] = useState({
    amount: '',
    timestamp: '',
    senderName: '',
    senderAccount: '',
    receiverName: '',
    receiverAccount: '',
    location: '',
    transactionType: '',
    description: ''
  });

  const [errors, setErrors] = useState({});
  const [suggestions, setSuggestions] = useState({
    payees: [],
    locations: []
  });

  // Mock data for suggestions
  const commonPayees = [
    "John Smith", "Sarah Johnson", "Michael Brown", "Emily Davis",
    "Amazon", "Netflix", "Spotify", "Uber", "Starbucks"
  ];

  const commonLocations = [
    "New York, NY", "Los Angeles, CA", "Chicago, IL", "Houston, TX",
    "Phoenix, AZ", "Philadelphia, PA", "San Antonio, TX", "San Diego, CA"
  ];

  const transactionTypes = [
    { value: 'upi', label: 'UPI Transfer' },
    { value: 'neft', label: 'NEFT' },
    { value: 'rtgs', label: 'RTGS' },
    { value: 'imps', label: 'IMPS' },
    { value: 'card', label: 'Card Payment' },
    { value: 'wallet', label: 'Digital Wallet' },
    { value: 'cash', label: 'Cash Deposit' },
    { value: 'cheque', label: 'Cheque' }
  ];

  // Set default timestamp to current time
  useEffect(() => {
    const now = new Date();
    const localDateTime = new Date(now.getTime() - now.getTimezoneOffset() * 60000)?.toISOString()?.slice(0, 16);
    setFormData(prev => ({ ...prev, timestamp: localDateTime }));
  }, []);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear error when user starts typing
    if (errors?.[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }

    // Provide suggestions for receiver name and location
    if (field === 'receiverName' && value?.length > 0) {
      const filtered = commonPayees?.filter(payee => 
        payee?.toLowerCase()?.includes(value?.toLowerCase())
      );
      setSuggestions(prev => ({ ...prev, payees: filtered?.slice(0, 5) }));
    }

    if (field === 'location' && value?.length > 0) {
      const filtered = commonLocations?.filter(location => 
        location?.toLowerCase()?.includes(value?.toLowerCase())
      );
      setSuggestions(prev => ({ ...prev, locations: filtered?.slice(0, 5) }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData?.amount || parseFloat(formData?.amount) <= 0) {
      newErrors.amount = 'Please enter a valid amount';
    }

    if (!formData?.timestamp) {
      newErrors.timestamp = 'Please select a timestamp';
    }

    if (!formData?.senderName?.trim()) {
      newErrors.senderName = 'Sender name is required';
    }

    if (!formData?.senderAccount?.trim()) {
      newErrors.senderAccount = 'Sender account is required';
    }

    if (!formData?.receiverName?.trim()) {
      newErrors.receiverName = 'Receiver name is required';
    }

    if (!formData?.receiverAccount?.trim()) {
      newErrors.receiverAccount = 'Receiver account is required';
    }

    if (!formData?.location?.trim()) {
      newErrors.location = 'Location is required';
    }

    if (!formData?.transactionType) {
      newErrors.transactionType = 'Please select transaction type';
    }

    // Account number validation
    if (formData?.senderAccount && !/^\d{10,16}$/?.test(formData?.senderAccount?.replace(/\s/g, ''))) {
      newErrors.senderAccount = 'Account number must be 10-16 digits';
    }

    if (formData?.receiverAccount && !/^\d{10,16}$/?.test(formData?.receiverAccount?.replace(/\s/g, ''))) {
      newErrors.receiverAccount = 'Account number must be 10-16 digits';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const handleSuggestionClick = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setSuggestions(prev => ({ 
      ...prev, 
      [field === 'receiverName' ? 'payees' : 'locations']: [] 
    }));
  };

  return (
    <div className="bg-card rounded-lg shadow-card border border-border p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="flex items-center justify-center w-10 h-10 bg-primary/10 rounded-lg">
          <Icon name="CreditCard" size={20} color="var(--color-primary)" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-text-primary">Transaction Details</h2>
          <p className="text-sm text-text-secondary">Enter transaction information for fraud analysis</p>
        </div>
      </div>
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Amount and Timestamp Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input
            label="Transaction Amount"
            type="number"
            placeholder="0.00"
            value={formData?.amount}
            onChange={(e) => handleInputChange('amount', e?.target?.value)}
            error={errors?.amount}
            required
            min="0.01"
            step="0.01"
          />
          
          <Input
            label="Transaction Timestamp"
            type="datetime-local"
            value={formData?.timestamp}
            onChange={(e) => handleInputChange('timestamp', e?.target?.value)}
            error={errors?.timestamp}
            required
          />
        </div>

        {/* Sender Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-text-primary flex items-center space-x-2">
            <Icon name="ArrowUp" size={18} color="var(--color-error)" />
            <span>Sender Information</span>
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input
              label="Sender Name"
              type="text"
              placeholder="Enter sender's full name"
              value={formData?.senderName}
              onChange={(e) => handleInputChange('senderName', e?.target?.value)}
              error={errors?.senderName}
              required
            />
            
            <Input
              label="Sender Account Number"
              type="text"
              placeholder="Enter account number"
              value={formData?.senderAccount}
              onChange={(e) => handleInputChange('senderAccount', e?.target?.value)}
              error={errors?.senderAccount}
              required
            />
          </div>
        </div>

        {/* Receiver Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-text-primary flex items-center space-x-2">
            <Icon name="ArrowDown" size={18} color="var(--color-success)" />
            <span>Receiver Information</span>
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="relative">
              <Input
                label="Receiver Name"
                type="text"
                placeholder="Enter receiver's full name"
                value={formData?.receiverName}
                onChange={(e) => handleInputChange('receiverName', e?.target?.value)}
                error={errors?.receiverName}
                required
              />
              
              {/* Payee Suggestions */}
              {suggestions?.payees?.length > 0 && (
                <div className="absolute top-full left-0 right-0 z-10 mt-1 bg-card border border-border rounded-lg shadow-dropdown max-h-40 overflow-y-auto">
                  {suggestions?.payees?.map((payee, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => handleSuggestionClick('receiverName', payee)}
                      className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-muted transition-micro"
                    >
                      {payee}
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <Input
              label="Receiver Account Number"
              type="text"
              placeholder="Enter account number"
              value={formData?.receiverAccount}
              onChange={(e) => handleInputChange('receiverAccount', e?.target?.value)}
              error={errors?.receiverAccount}
              required
            />
          </div>
        </div>

        {/* Transaction Details */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-text-primary flex items-center space-x-2">
            <Icon name="MapPin" size={18} color="var(--color-accent)" />
            <span>Transaction Details</span>
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="relative">
              <Input
                label="Transaction Location"
                type="text"
                placeholder="Enter city, state"
                value={formData?.location}
                onChange={(e) => handleInputChange('location', e?.target?.value)}
                error={errors?.location}
                required
              />
              
              {/* Location Suggestions */}
              {suggestions?.locations?.length > 0 && (
                <div className="absolute top-full left-0 right-0 z-10 mt-1 bg-card border border-border rounded-lg shadow-dropdown max-h-40 overflow-y-auto">
                  {suggestions?.locations?.map((location, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => handleSuggestionClick('location', location)}
                      className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-muted transition-micro"
                    >
                      {location}
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <Select
              label="Transaction Type"
              placeholder="Select transaction type"
              options={transactionTypes}
              value={formData?.transactionType}
              onChange={(value) => handleInputChange('transactionType', value)}
              error={errors?.transactionType}
              required
            />
          </div>
        </div>

        {/* Description */}
        <Input
          label="Description (Optional)"
          type="text"
          placeholder="Enter transaction description or notes"
          value={formData?.description}
          onChange={(e) => handleInputChange('description', e?.target?.value)}
        />

        {/* Submit Button */}
        <div className="flex justify-end pt-4">
          <Button
            type="submit"
            variant="default"
            size="lg"
            loading={isAnalyzing}
            iconName="Shield"
            iconPosition="left"
            className="min-w-48"
          >
            {isAnalyzing ? 'Analyzing Transaction...' : 'Analyze Transaction'}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default TransactionForm;