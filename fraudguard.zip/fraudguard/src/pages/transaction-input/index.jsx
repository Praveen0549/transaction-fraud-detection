import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import TransactionForm from './components/TransactionForm';
import FraudAnalysisResult from './components/FraudAnalysisResult';
import BulkUploadSection from './components/BulkUploadSection';
import AdvancedOptions from './components/AdvancedOptions';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const TransactionInput = () => {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState('single'); // single, bulk
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [advancedOptions, setAdvancedOptions] = useState({
    detectionModel: 'standard',
    riskThreshold: 'balanced',
    analysisDepth: 'standard',
    behavioralAnalysis: true,
    geolocationVerification: true,
    timePatternAnalysis: true,
    dashboardAlerts: true
  });

  // Mock fraud analysis function
  const performFraudAnalysis = (transactionData) => {
    setIsAnalyzing(true);
    
    // Simulate API call delay
    setTimeout(() => {
      // Mock analysis logic based on transaction data
      const amount = parseFloat(transactionData?.amount);
      const isHighAmount = amount > 10000;
      const isUnusualTime = new Date(transactionData.timestamp)?.getHours() < 6 || new Date(transactionData.timestamp)?.getHours() > 22;
      const isInternational = transactionData?.location?.toLowerCase()?.includes('international');
      
      // Calculate risk factors
      const amountRisk = Math.min(amount / 20000, 1) * 0.8 + Math.random() * 0.2;
      const timeRisk = isUnusualTime ? 0.7 + Math.random() * 0.3 : Math.random() * 0.4;
      const locationRisk = isInternational ? 0.8 + Math.random() * 0.2 : Math.random() * 0.3;
      const behaviorRisk = Math.random() * 0.6;
      
      // Overall fraud probability
      const fraudProbability = Math.min((amountRisk + timeRisk + locationRisk + behaviorRisk) / 4, 1);
      
      const result = {
        fraudProbability: fraudProbability,
        amountRisk: amountRisk,
        timeRisk: timeRisk,
        locationRisk: locationRisk,
        behaviorRisk: behaviorRisk,
        amount: transactionData?.amount,
        type: transactionData?.transactionType,
        location: transactionData?.location,
        sender: transactionData?.senderName,
        receiver: transactionData?.receiverName,
        timestamp: new Date(transactionData.timestamp)?.toLocaleString(),
        analysisId: `ANALYSIS_${Date.now()}`,
        processingTime: `${(Math.random() * 2 + 1)?.toFixed(1)}s`
      };
      
      setAnalysisResult(result);
      setIsAnalyzing(false);
    }, 3000);
  };

  const handleFormSubmit = (transactionData) => {
    performFraudAnalysis(transactionData);
  };

  const handleBulkAnalysis = (bulkResults) => {
    console.log('Bulk analysis completed:', bulkResults);
  };

  const handleReset = () => {
    setAnalysisResult(null);
    setIsAnalyzing(false);
  };

  const handleAdvancedOptionsChange = (options) => {
    setAdvancedOptions(options);
  };

  const handleNavigateToDetails = () => {
    if (analysisResult) {
      navigate('/transaction-details', { 
        state: { 
          transactionData: analysisResult,
          fromAnalysis: true 
        } 
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header userRole="analyst" alertCount={3} />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold text-text-primary">Transaction Analysis</h1>
                <p className="text-text-secondary mt-2">
                  Analyze individual transactions or upload bulk data for fraud detection
                </p>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 text-sm text-text-secondary">
                  <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
                  <span>AI Models Online</span>
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  iconName="ArrowLeft"
                  iconPosition="left"
                  onClick={() => navigate('/user-dashboard')}
                >
                  Back to Dashboard
                </Button>
              </div>
            </div>

            {/* View Toggle */}
            <div className="flex items-center space-x-1 bg-muted p-1 rounded-lg w-fit">
              <button
                onClick={() => setCurrentView('single')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-micro ${
                  currentView === 'single' ?'bg-card text-text-primary shadow-sm' :'text-text-secondary hover:text-text-primary'
                }`}
              >
                <Icon name="FileText" size={16} />
                <span>Single Transaction</span>
              </button>
              <button
                onClick={() => setCurrentView('bulk')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-micro ${
                  currentView === 'bulk' ?'bg-card text-text-primary shadow-sm' :'text-text-secondary hover:text-text-primary'
                }`}
              >
                <Icon name="Upload" size={16} />
                <span>Bulk Upload</span>
              </button>
            </div>
          </div>

          {/* Content Area */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="xl:col-span-2 space-y-8">
              {currentView === 'single' ? (
                <>
                  {!analysisResult ? (
                    <TransactionForm 
                      onSubmit={handleFormSubmit}
                      isAnalyzing={isAnalyzing}
                    />
                  ) : (
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <h2 className="text-2xl font-semibold text-text-primary">Analysis Results</h2>
                        <Button
                          variant="outline"
                          size="sm"
                          iconName="ExternalLink"
                          iconPosition="right"
                          onClick={handleNavigateToDetails}
                        >
                          View Full Details
                        </Button>
                      </div>
                      
                      <FraudAnalysisResult 
                        result={analysisResult}
                        onReset={handleReset}
                      />
                    </div>
                  )}
                </>
              ) : (
                <BulkUploadSection onBulkAnalysis={handleBulkAnalysis} />
              )}

              {/* Processing Status */}
              {isAnalyzing && (
                <div className="bg-card rounded-lg shadow-card border border-border p-6">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg">
                      <Icon name="Zap" size={24} color="var(--color-primary)" className="animate-pulse" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-text-primary">Analyzing Transaction</h3>
                      <p className="text-sm text-text-secondary">
                        AI models are processing the transaction data...
                      </p>
                      <div className="mt-3 w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full animate-pulse" style={{ width: '100%' }} />
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Advanced Options */}
              <AdvancedOptions 
                options={advancedOptions}
                onOptionsChange={handleAdvancedOptionsChange}
              />

              {/* Quick Stats */}
              <div className="bg-card rounded-lg shadow-card border border-border p-6">
                <h3 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
                  <Icon name="BarChart3" size={20} color="var(--color-primary)" />
                  <span>Today's Analysis</span>
                </h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">Transactions Analyzed</span>
                    <span className="text-sm font-semibold text-text-primary">247</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">Fraud Detected</span>
                    <span className="text-sm font-semibold text-error">12</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">False Positives</span>
                    <span className="text-sm font-semibold text-warning">3</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">Accuracy Rate</span>
                    <span className="text-sm font-semibold text-success">94.2%</span>
                  </div>
                </div>
              </div>

              {/* Recent Activity */}
              <div className="bg-card rounded-lg shadow-card border border-border p-6">
                <h3 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
                  <Icon name="Clock" size={20} color="var(--color-secondary)" />
                  <span>Recent Activity</span>
                </h3>
                
                <div className="space-y-3">
                  {[
                    { time: '2 min ago', action: 'High-risk transaction flagged', type: 'error' },
                    { time: '5 min ago', action: 'Bulk analysis completed', type: 'success' },
                    { time: '12 min ago', action: 'Model updated successfully', type: 'info' },
                    { time: '18 min ago', action: 'Suspicious pattern detected', type: 'warning' }
                  ]?.map((activity, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className={`w-2 h-2 rounded-full mt-2 ${
                        activity?.type === 'error' ? 'bg-error' :
                        activity?.type === 'success' ? 'bg-success' :
                        activity?.type === 'warning' ? 'bg-warning' : 'bg-primary'
                      }`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-text-primary">{activity?.action}</p>
                        <p className="text-xs text-text-secondary">{activity?.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Help & Support */}
              <div className="bg-card rounded-lg shadow-card border border-border p-6">
                <h3 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
                  <Icon name="HelpCircle" size={20} color="var(--color-accent)" />
                  <span>Need Help?</span>
                </h3>
                
                <div className="space-y-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="Book"
                    iconPosition="left"
                    fullWidth
                    className="justify-start"
                  >
                    View Documentation
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="MessageCircle"
                    iconPosition="left"
                    fullWidth
                    className="justify-start"
                  >
                    Contact Support
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="Video"
                    iconPosition="left"
                    fullWidth
                    className="justify-start"
                  >
                    Watch Tutorial
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default TransactionInput;