import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TransactionCard = ({ transaction, onViewDetails }) => {
  const getRiskColor = (probability) => {
    if (probability >= 0.8) return 'text-error bg-red-50 border-red-200';
    if (probability >= 0.5) return 'text-warning bg-amber-50 border-amber-200';
    return 'text-success bg-green-50 border-green-200';
  };

  const getRiskLabel = (probability) => {
    if (probability >= 0.8) return 'High Risk';
    if (probability >= 0.5) return 'Medium Risk';
    return 'Low Risk';
  };

  const formatAmount = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    })?.format(amount);
  };

  const formatTime = (timestamp) => {
    return new Date(timestamp)?.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 hover:shadow-card transition-standard">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${transaction?.type === 'sent' ? 'bg-red-50' : 'bg-green-50'}`}>
            <Icon 
              name={transaction?.type === 'sent' ? 'ArrowUpRight' : 'ArrowDownLeft'} 
              size={20} 
              color={transaction?.type === 'sent' ? 'var(--color-error)' : 'var(--color-success)'} 
            />
          </div>
          <div>
            <p className="font-semibold text-text-primary">{formatAmount(transaction?.amount)}</p>
            <p className="text-sm text-text-secondary">{formatTime(transaction?.timestamp)}</p>
          </div>
        </div>
        <div className={`px-2 py-1 rounded-full text-xs font-medium border ${getRiskColor(transaction?.fraudProbability)}`}>
          {getRiskLabel(transaction?.fraudProbability)}
        </div>
      </div>
      <div className="flex items-center justify-between mb-3">
        <div>
          <p className="text-sm text-text-secondary">
            {transaction?.type === 'sent' ? 'To:' : 'From:'} {transaction?.recipient}
          </p>
          <p className="text-xs text-text-secondary">{transaction?.location}</p>
        </div>
        <div className="text-right">
          <p className="text-sm font-medium text-text-primary">
            {Math.round(transaction?.fraudProbability * 100)}% Risk
          </p>
          <p className="text-xs text-text-secondary">Confidence: {transaction?.confidence}%</p>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Icon name="Shield" size={16} color="var(--color-text-secondary)" />
          <span className="text-xs text-text-secondary">ID: {transaction?.id}</span>
        </div>
        <Button
          variant="outline"
          size="sm"
          iconName="Eye"
          iconPosition="left"
          onClick={() => onViewDetails(transaction)}
        >
          View Details
        </Button>
      </div>
    </div>
  );
};

export default TransactionCard;