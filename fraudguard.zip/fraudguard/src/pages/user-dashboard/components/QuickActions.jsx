import React from 'react';
import Button from '../../../components/ui/Button';

const QuickActions = ({ onVerifyTransaction, onFileDispute, onManageAlerts, onViewReports }) => {
  const actions = [
    {
      label: 'Verify Transaction',
      icon: 'Shield',
      variant: 'default',
      onClick: onVerifyTransaction,
      description: 'Verify recent transactions'
    },
    {
      label: 'File Dispute',
      icon: 'AlertTriangle',
      variant: 'outline',
      onClick: onFileDispute,
      description: 'Report fraudulent activity'
    },
    {
      label: 'Manage Alerts',
      icon: 'Bell',
      variant: 'secondary',
      onClick: onManageAlerts,
      description: 'Configure notifications'
    },
    {
      label: 'View Reports',
      icon: 'FileText',
      variant: 'ghost',
      onClick: onViewReports,
      description: 'Access detailed reports'
    }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <h3 className="text-lg font-semibold text-text-primary mb-4">Quick Actions</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {actions?.map((action, index) => (
          <div key={index} className="text-center">
            <Button
              variant={action?.variant}
              size="lg"
              iconName={action?.icon}
              iconPosition="left"
              onClick={action?.onClick}
              fullWidth
              className="mb-2"
            >
              {action?.label}
            </Button>
            <p className="text-xs text-text-secondary">{action?.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;