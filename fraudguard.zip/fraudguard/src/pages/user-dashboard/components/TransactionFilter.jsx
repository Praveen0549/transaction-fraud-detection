import React from 'react';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const TransactionFilter = ({ filters, onFilterChange, onReset }) => {
  const riskLevelOptions = [
    { value: 'all', label: 'All Risk Levels' },
    { value: 'low', label: 'Low Risk' },
    { value: 'medium', label: 'Medium Risk' },
    { value: 'high', label: 'High Risk' }
  ];

  const transactionTypeOptions = [
    { value: 'all', label: 'All Types' },
    { value: 'sent', label: 'Sent' },
    { value: 'received', label: 'Received' }
  ];

  const amountRangeOptions = [
    { value: 'all', label: 'All Amounts' },
    { value: '0-100', label: '$0 - $100' },
    { value: '100-500', label: '$100 - $500' },
    { value: '500-1000', label: '$500 - $1,000' },
    { value: '1000+', label: '$1,000+' }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-text-primary">Filter Transactions</h3>
        <Button
          variant="ghost"
          size="sm"
          iconName="RotateCcw"
          iconPosition="left"
          onClick={onReset}
        >
          Reset
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <Input
          type="search"
          placeholder="Search transactions..."
          value={filters?.search}
          onChange={(e) => onFilterChange('search', e?.target?.value)}
        />
        
        <Select
          placeholder="Risk Level"
          options={riskLevelOptions}
          value={filters?.riskLevel}
          onChange={(value) => onFilterChange('riskLevel', value)}
        />
        
        <Select
          placeholder="Transaction Type"
          options={transactionTypeOptions}
          value={filters?.type}
          onChange={(value) => onFilterChange('type', value)}
        />
        
        <Select
          placeholder="Amount Range"
          options={amountRangeOptions}
          value={filters?.amountRange}
          onChange={(value) => onFilterChange('amountRange', value)}
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          type="date"
          label="From Date"
          value={filters?.fromDate}
          onChange={(e) => onFilterChange('fromDate', e?.target?.value)}
        />
        
        <Input
          type="date"
          label="To Date"
          value={filters?.toDate}
          onChange={(e) => onFilterChange('toDate', e?.target?.value)}
        />
      </div>
    </div>
  );
};

export default TransactionFilter;