import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AlertNotification = ({ alert, onDismiss, onViewDetails }) => {
  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high':
        return 'bg-red-50 border-red-200 text-red-800';
      case 'medium':
        return 'bg-amber-50 border-amber-200 text-amber-800';
      case 'low':
        return 'bg-blue-50 border-blue-200 text-blue-800';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-800';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'high':
        return 'AlertTriangle';
      case 'medium':
        return 'AlertCircle';
      case 'low':
        return 'Info';
      default:
        return 'Bell';
    }
  };

  const formatTime = (timestamp) => {
    return new Date(timestamp)?.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className={`border rounded-lg p-4 mb-3 ${getSeverityColor(alert?.severity)}`}>
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3">
          <Icon name={getSeverityIcon(alert?.severity)} size={20} />
          <div className="flex-1">
            <h4 className="font-semibold mb-1">{alert?.title}</h4>
            <p className="text-sm mb-2">{alert?.message}</p>
            <div className="flex items-center space-x-4 text-xs">
              <span>Confidence: {alert?.confidence}%</span>
              <span>{formatTime(alert?.timestamp)}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            iconName="Eye"
            onClick={() => onViewDetails(alert)}
          />
          <Button
            variant="ghost"
            size="sm"
            iconName="X"
            onClick={() => onDismiss(alert?.id)}
          />
        </div>
      </div>
    </div>
  );
};

export default AlertNotification;