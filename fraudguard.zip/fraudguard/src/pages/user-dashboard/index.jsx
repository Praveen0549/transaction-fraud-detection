import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import TransactionCard from './components/TransactionCard';
import SummaryCard from './components/SummaryCard';
import FraudAnalyticsChart from './components/FraudAnalyticsChart';
import QuickActions from './components/QuickActions';
import AlertNotification from './components/AlertNotification';
import TransactionFilter from './components/TransactionFilter';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const UserDashboard = () => {
  const navigate = useNavigate();
  const [showFilters, setShowFilters] = useState(false);
  const [alerts, setAlerts] = useState([]);
  const [filters, setFilters] = useState({
    search: '',
    riskLevel: 'all',
    type: 'all',
    amountRange: 'all',
    fromDate: '',
    toDate: ''
  });

  // Mock data for recent transactions
  const recentTransactions = [
    {
      id: "TXN001",
      amount: 250.00,
      type: "sent",
      recipient: "John Smith",
      location: "New York, NY",
      timestamp: new Date(Date.now() - 3600000),
      fraudProbability: 0.15,
      confidence: 92
    },
    {
      id: "TXN002", 
      amount: 1500.00,
      type: "received",
      recipient: "Sarah Johnson",
      location: "Los Angeles, CA",
      timestamp: new Date(Date.now() - 7200000),
      fraudProbability: 0.75,
      confidence: 88
    },
    {
      id: "TXN003",
      amount: 75.50,
      type: "sent", 
      recipient: "Mike Wilson",
      location: "Chicago, IL",
      timestamp: new Date(Date.now() - 10800000),
      fraudProbability: 0.25,
      confidence: 95
    },
    {
      id: "TXN004",
      amount: 3200.00,
      type: "sent",
      recipient: "Unknown User",
      location: "Miami, FL",
      timestamp: new Date(Date.now() - 14400000),
      fraudProbability: 0.95,
      confidence: 97
    },
    {
      id: "TXN005",
      amount: 125.00,
      type: "received",
      recipient: "Emma Davis",
      location: "Seattle, WA",
      timestamp: new Date(Date.now() - 18000000),
      fraudProbability: 0.10,
      confidence: 89
    }
  ];

  // Mock data for summary cards
  const summaryData = [
    {
      title: "Total Transactions",
      value: "247",
      subtitle: "This month",
      icon: "CreditCard",
      trend: 12,
      color: "primary"
    },
    {
      title: "Flagged Items",
      value: "3",
      subtitle: "Requires attention",
      icon: "AlertTriangle", 
      trend: -25,
      color: "warning"
    },
    {
      title: "Security Score",
      value: "94%",
      subtitle: "Account protection",
      icon: "Shield",
      trend: 5,
      color: "success"
    },
    {
      title: "Account Balance",
      value: "$12,450",
      subtitle: "Available funds",
      icon: "Wallet",
      trend: 8,
      color: "primary"
    }
  ];

  // Mock data for fraud analytics
  const riskDistributionData = [
    { name: 'Low Risk', value: 185 },
    { name: 'Medium Risk', value: 45 },
    { name: 'High Risk', value: 17 }
  ];

  const monthlyTrendsData = [
    { name: 'Jan', value: 23 },
    { name: 'Feb', value: 18 },
    { name: 'Mar', value: 31 },
    { name: 'Apr', value: 25 },
    { name: 'May', value: 42 },
    { name: 'Jun', value: 38 }
  ];

  // Mock alerts data
  const mockAlerts = [
    {
      id: 1,
      title: "High-Risk Transaction Detected",
      message: "A transaction of $3,200 to an unknown recipient has been flagged with 95% fraud probability.",
      severity: "high",
      confidence: 97,
      timestamp: new Date(Date.now() - 1800000)
    },
    {
      id: 2,
      title: "Unusual Location Activity",
      message: "Transaction initiated from Miami, FL - outside your usual activity area.",
      severity: "medium",
      confidence: 88,
      timestamp: new Date(Date.now() - 3600000)
    }
  ];

  useEffect(() => {
    setAlerts(mockAlerts);
  }, []);

  const handleViewTransactionDetails = (transaction) => {
    navigate('/transaction-details', { state: { transaction } });
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleResetFilters = () => {
    setFilters({
      search: '',
      riskLevel: 'all',
      type: 'all',
      amountRange: 'all',
      fromDate: '',
      toDate: ''
    });
  };

  const handleDismissAlert = (alertId) => {
    setAlerts(prev => prev?.filter(alert => alert?.id !== alertId));
  };

  const handleViewAlertDetails = (alert) => {
    console.log('Viewing alert details:', alert);
  };

  const handleVerifyTransaction = () => {
    navigate('/transaction-input');
  };

  const handleFileDispute = () => {
    console.log('Filing dispute...');
  };

  const handleManageAlerts = () => {
    console.log('Managing alerts...');
  };

  const handleViewReports = () => {
    navigate('/reports');
  };

  const filteredTransactions = recentTransactions?.filter(transaction => {
    if (filters?.search && !transaction?.recipient?.toLowerCase()?.includes(filters?.search?.toLowerCase()) && 
        !transaction?.id?.toLowerCase()?.includes(filters?.search?.toLowerCase())) {
      return false;
    }
    
    if (filters?.riskLevel !== 'all') {
      const riskLevel = transaction?.fraudProbability >= 0.8 ? 'high' : 
                       transaction?.fraudProbability >= 0.5 ? 'medium' : 'low';
      if (riskLevel !== filters?.riskLevel) return false;
    }
    
    if (filters?.type !== 'all' && transaction?.type !== filters?.type) {
      return false;
    }
    
    return true;
  });

  return (
    <div className="min-h-screen bg-background">
      <Header userRole="customer" alertCount={alerts?.length} />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
          {/* Page Header */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-text-primary mb-2">Dashboard</h1>
              <p className="text-text-secondary">Monitor your transactions and account security</p>
            </div>
            <div className="flex items-center space-x-4 mt-4 lg:mt-0">
              <Button
                variant="outline"
                iconName="Filter"
                iconPosition="left"
                onClick={() => setShowFilters(!showFilters)}
              >
                Filters
              </Button>
              <Button
                variant="default"
                iconName="Plus"
                iconPosition="left"
                onClick={() => navigate('/transaction-input')}
              >
                New Transaction
              </Button>
            </div>
          </div>

          {/* Alerts Section */}
          {alerts?.length > 0 && (
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-text-primary mb-4 flex items-center">
                <Icon name="Bell" size={20} className="mr-2" />
                Security Alerts ({alerts?.length})
              </h2>
              <div className="space-y-3">
                {alerts?.map(alert => (
                  <AlertNotification
                    key={alert?.id}
                    alert={alert}
                    onDismiss={handleDismissAlert}
                    onViewDetails={handleViewAlertDetails}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {summaryData?.map((item, index) => (
              <SummaryCard
                key={index}
                title={item?.title}
                value={item?.value}
                subtitle={item?.subtitle}
                icon={item?.icon}
                trend={item?.trend}
                color={item?.color}
              />
            ))}
          </div>

          {/* Quick Actions */}
          <div className="mb-8">
            <QuickActions
              onVerifyTransaction={handleVerifyTransaction}
              onFileDispute={handleFileDispute}
              onManageAlerts={handleManageAlerts}
              onViewReports={handleViewReports}
            />
          </div>

          {/* Analytics Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <FraudAnalyticsChart
              type="pie"
              data={riskDistributionData}
              title="Risk Distribution"
            />
            <FraudAnalyticsChart
              type="bar"
              data={monthlyTrendsData}
              title="Monthly Transaction Trends"
            />
          </div>

          {/* Transaction Filters */}
          {showFilters && (
            <TransactionFilter
              filters={filters}
              onFilterChange={handleFilterChange}
              onReset={handleResetFilters}
            />
          )}

          {/* Recent Transactions */}
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-text-primary">
                Recent Transactions ({filteredTransactions?.length})
              </h2>
              <Button
                variant="ghost"
                iconName="ArrowRight"
                iconPosition="right"
                onClick={() => navigate('/transaction-details')}
              >
                View All
              </Button>
            </div>
            
            {filteredTransactions?.length > 0 ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {filteredTransactions?.slice(0, 6)?.map(transaction => (
                  <TransactionCard
                    key={transaction?.id}
                    transaction={transaction}
                    onViewDetails={handleViewTransactionDetails}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Icon name="Search" size={48} color="var(--color-text-secondary)" className="mx-auto mb-4" />
                <h3 className="text-lg font-medium text-text-primary mb-2">No transactions found</h3>
                <p className="text-text-secondary mb-4">Try adjusting your filters or search criteria</p>
                <Button
                  variant="outline"
                  iconName="RotateCcw"
                  iconPosition="left"
                  onClick={handleResetFilters}
                >
                  Reset Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default UserDashboard;