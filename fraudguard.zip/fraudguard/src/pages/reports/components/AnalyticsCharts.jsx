import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const AnalyticsCharts = () => {
  const [selectedChart, setSelectedChart] = useState('fraud_trends');
  const [timeRange, setTimeRange] = useState('7_days');

  const chartOptions = [
    { value: 'fraud_trends', label: 'Fraud Detection Trends' },
    { value: 'transaction_volume', label: 'Transaction Volume' },
    { value: 'risk_distribution', label: 'Risk Score Distribution' },
    { value: 'geographic_analysis', label: 'Geographic Analysis' },
    { value: 'false_positive_rates', label: 'False Positive Rates' }
  ];

  const timeRangeOptions = [
    { value: '7_days', label: 'Last 7 Days' },
    { value: '30_days', label: 'Last 30 Days' },
    { value: '90_days', label: 'Last 90 Days' },
    { value: '1_year', label: 'Last Year' }
  ];

  // Mock data for different chart types
  const fraudTrendsData = [
    { date: '09/03', legitimate: 1250, fraudulent: 45, flagged: 23 },
    { date: '09/04', legitimate: 1180, fraudulent: 52, flagged: 31 },
    { date: '09/05', legitimate: 1320, fraudulent: 38, flagged: 19 },
    { date: '09/06', legitimate: 1450, fraudulent: 41, flagged: 27 },
    { date: '09/07', legitimate: 1380, fraudulent: 49, flagged: 34 },
    { date: '09/08', legitimate: 1520, fraudulent: 36, flagged: 22 },
    { date: '09/09', legitimate: 1420, fraudulent: 43, flagged: 28 }
  ];

  const transactionVolumeData = [
    { hour: '00:00', volume: 120, avgAmount: 245 },
    { hour: '04:00', volume: 85, avgAmount: 180 },
    { hour: '08:00', volume: 450, avgAmount: 320 },
    { hour: '12:00', volume: 680, avgAmount: 280 },
    { hour: '16:00', volume: 520, avgAmount: 310 },
    { hour: '20:00', volume: 380, avgAmount: 290 },
    { hour: '23:00', volume: 220, avgAmount: 260 }
  ];

  const riskDistributionData = [
    { name: 'Low Risk (0-30)', value: 1250, color: '#10B981' },
    { name: 'Medium Risk (31-70)', value: 340, color: '#F59E0B' },
    { name: 'High Risk (71-90)', value: 120, color: '#EF4444' },
    { name: 'Critical Risk (91-100)', value: 45, color: '#7C2D12' }
  ];

  const geographicData = [
    { region: 'North America', transactions: 2450, fraudRate: 2.1 },
    { region: 'Europe', transactions: 1890, fraudRate: 1.8 },
    { region: 'Asia Pacific', transactions: 3200, fraudRate: 2.8 },
    { region: 'Latin America', transactions: 980, fraudRate: 3.2 },
    { region: 'Middle East', transactions: 650, fraudRate: 2.5 },
    { region: 'Africa', transactions: 420, fraudRate: 3.8 }
  ];

  const falsePositiveData = [
    { week: 'Week 1', rate: 4.2, target: 3.0 },
    { week: 'Week 2', rate: 3.8, target: 3.0 },
    { week: 'Week 3', rate: 3.1, target: 3.0 },
    { week: 'Week 4', rate: 2.9, target: 3.0 }
  ];

  const renderChart = () => {
    switch (selectedChart) {
      case 'fraud_trends':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <AreaChart data={fraudTrendsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="date" stroke="var(--color-text-secondary)" />
              <YAxis stroke="var(--color-text-secondary)" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--color-card)', 
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px'
                }} 
              />
              <Area type="monotone" dataKey="legitimate" stackId="1" stroke="#10B981" fill="#10B981" fillOpacity={0.6} />
              <Area type="monotone" dataKey="flagged" stackId="1" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.6} />
              <Area type="monotone" dataKey="fraudulent" stackId="1" stroke="#EF4444" fill="#EF4444" fillOpacity={0.6} />
            </AreaChart>
          </ResponsiveContainer>
        );

      case 'transaction_volume':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={transactionVolumeData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="hour" stroke="var(--color-text-secondary)" />
              <YAxis stroke="var(--color-text-secondary)" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--color-card)', 
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px'
                }} 
              />
              <Bar dataKey="volume" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        );

      case 'risk_distribution':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <PieChart>
              <Pie
                data={riskDistributionData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={120}
                paddingAngle={5}
                dataKey="value"
              >
                {riskDistributionData?.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry?.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--color-card)', 
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px'
                }} 
              />
            </PieChart>
          </ResponsiveContainer>
        );

      case 'geographic_analysis':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={geographicData} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis type="number" stroke="var(--color-text-secondary)" />
              <YAxis dataKey="region" type="category" stroke="var(--color-text-secondary)" width={100} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--color-card)', 
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px'
                }} 
              />
              <Bar dataKey="transactions" fill="var(--color-primary)" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        );

      case 'false_positive_rates':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={falsePositiveData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="week" stroke="var(--color-text-secondary)" />
              <YAxis stroke="var(--color-text-secondary)" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--color-card)', 
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px'
                }} 
              />
              <Line type="monotone" dataKey="rate" stroke="#EF4444" strokeWidth={3} dot={{ fill: '#EF4444', strokeWidth: 2, r: 6 }} />
              <Line type="monotone" dataKey="target" stroke="#10B981" strokeWidth={2} strokeDasharray="5 5" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        );

      default:
        return null;
    }
  };

  const getChartDescription = () => {
    const descriptions = {
      'fraud_trends': 'Daily fraud detection trends showing legitimate, flagged, and fraudulent transactions over time',
      'transaction_volume': 'Hourly transaction volume patterns with average transaction amounts',
      'risk_distribution': 'Distribution of transactions across different risk score categories',
      'geographic_analysis': 'Transaction volume and fraud rates by geographic region',
      'false_positive_rates': 'Weekly false positive rates compared to target thresholds'
    };
    return descriptions?.[selectedChart] || '';
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-10 h-10 bg-success/10 rounded-lg">
            <Icon name="BarChart3" size={20} color="var(--color-success)" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-text-primary">Interactive Analytics</h2>
            <p className="text-sm text-text-secondary">Real-time fraud detection visualizations</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" iconName="Download" size="sm">
            Export Chart
          </Button>
          <Button variant="ghost" iconName="Maximize2" size="sm" />
        </div>
      </div>
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <Select
            label="Chart Type"
            options={chartOptions}
            value={selectedChart}
            onChange={setSelectedChart}
            className="min-w-[200px]"
          />
          <Select
            label="Time Range"
            options={timeRangeOptions}
            value={timeRange}
            onChange={setTimeRange}
            className="min-w-[150px]"
          />
        </div>
      </div>
      <div className="mb-4">
        <p className="text-sm text-text-secondary">{getChartDescription()}</p>
      </div>
      <div className="bg-background rounded-lg p-4">
        {renderChart()}
      </div>
      {selectedChart === 'risk_distribution' && (
        <div className="mt-4 grid grid-cols-2 lg:grid-cols-4 gap-4">
          {riskDistributionData?.map((item, index) => (
            <div key={index} className="flex items-center space-x-2">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: item?.color }}
              />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-text-primary truncate">{item?.name}</div>
                <div className="text-xs text-text-secondary">{item?.value?.toLocaleString()} transactions</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AnalyticsCharts;