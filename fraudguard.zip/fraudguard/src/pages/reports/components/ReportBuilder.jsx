import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const ReportBuilder = ({ onGenerateReport }) => {
  const [reportConfig, setReportConfig] = useState({
    reportType: '',
    dateRange: 'last_30_days',
    startDate: '',
    endDate: '',
    metrics: [],
    format: 'pdf',
    includeCharts: true
  });

  const reportTypes = [
    { value: 'fraud_detection', label: 'Fraud Detection Analysis' },
    { value: 'false_positive', label: 'False Positive Analysis' },
    { value: 'transaction_volume', label: 'Transaction Volume Trends' },
    { value: 'compliance_summary', label: 'Regulatory Compliance Summary' },
    { value: 'performance_metrics', label: 'System Performance Metrics' },
    { value: 'risk_assessment', label: 'Risk Assessment Report' }
  ];

  const dateRangeOptions = [
    { value: 'last_7_days', label: 'Last 7 Days' },
    { value: 'last_30_days', label: 'Last 30 Days' },
    { value: 'last_90_days', label: 'Last 90 Days' },
    { value: 'last_year', label: 'Last Year' },
    { value: 'custom', label: 'Custom Range' }
  ];

  const formatOptions = [
    { value: 'pdf', label: 'PDF Report' },
    { value: 'csv', label: 'CSV Data Export' },
    { value: 'excel', label: 'Excel Spreadsheet' },
    { value: 'dashboard', label: 'Interactive Dashboard' }
  ];

  const metricOptions = [
    { value: 'fraud_rate', label: 'Fraud Detection Rate' },
    { value: 'false_positive_rate', label: 'False Positive Rate' },
    { value: 'transaction_volume', label: 'Transaction Volume' },
    { value: 'risk_scores', label: 'Risk Score Distribution' },
    { value: 'geographic_data', label: 'Geographic Analysis' },
    { value: 'time_patterns', label: 'Time-based Patterns' }
  ];

  const handleInputChange = (field, value) => {
    setReportConfig(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleMetricToggle = (metric) => {
    setReportConfig(prev => ({
      ...prev,
      metrics: prev?.metrics?.includes(metric)
        ? prev?.metrics?.filter(m => m !== metric)
        : [...prev?.metrics, metric]
    }));
  };

  const handleGenerateReport = () => {
    if (!reportConfig?.reportType) {
      alert('Please select a report type');
      return;
    }
    onGenerateReport(reportConfig);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="flex items-center justify-center w-10 h-10 bg-primary/10 rounded-lg">
          <Icon name="FileText" size={20} color="var(--color-primary)" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-text-primary">Report Builder</h2>
          <p className="text-sm text-text-secondary">Create custom reports and analytics</p>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Report Configuration */}
        <div className="space-y-4">
          <Select
            label="Report Type"
            options={reportTypes}
            value={reportConfig?.reportType}
            onChange={(value) => handleInputChange('reportType', value)}
            placeholder="Select report type"
            required
          />

          <Select
            label="Date Range"
            options={dateRangeOptions}
            value={reportConfig?.dateRange}
            onChange={(value) => handleInputChange('dateRange', value)}
          />

          {reportConfig?.dateRange === 'custom' && (
            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Start Date"
                type="date"
                value={reportConfig?.startDate}
                onChange={(e) => handleInputChange('startDate', e?.target?.value)}
              />
              <Input
                label="End Date"
                type="date"
                value={reportConfig?.endDate}
                onChange={(e) => handleInputChange('endDate', e?.target?.value)}
              />
            </div>
          )}

          <Select
            label="Output Format"
            options={formatOptions}
            value={reportConfig?.format}
            onChange={(value) => handleInputChange('format', value)}
          />
        </div>

        {/* Metrics Selection */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-text-primary mb-3">
              Include Metrics
            </label>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {metricOptions?.map((metric) => (
                <label key={metric?.value} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={reportConfig?.metrics?.includes(metric?.value)}
                    onChange={() => handleMetricToggle(metric?.value)}
                    className="w-4 h-4 text-primary border-border rounded focus:ring-primary"
                  />
                  <span className="text-sm text-text-primary">{metric?.label}</span>
                </label>
              ))}
            </div>
          </div>

          <label className="flex items-center space-x-3 cursor-pointer">
            <input
              type="checkbox"
              checked={reportConfig?.includeCharts}
              onChange={(e) => handleInputChange('includeCharts', e?.target?.checked)}
              className="w-4 h-4 text-primary border-border rounded focus:ring-primary"
            />
            <span className="text-sm text-text-primary">Include Charts and Visualizations</span>
          </label>
        </div>
      </div>
      <div className="flex items-center justify-between mt-6 pt-6 border-t border-border">
        <div className="text-sm text-text-secondary">
          Report will be generated based on selected criteria
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" iconName="Save">
            Save Template
          </Button>
          <Button 
            variant="default" 
            iconName="Download"
            onClick={handleGenerateReport}
            disabled={!reportConfig?.reportType}
          >
            Generate Report
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ReportBuilder;