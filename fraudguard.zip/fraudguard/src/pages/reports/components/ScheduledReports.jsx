import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';

const ScheduledReports = () => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newSchedule, setNewSchedule] = useState({
    name: '',
    reportType: '',
    frequency: '',
    recipients: '',
    format: 'pdf'
  });

  const scheduledReports = [
    {
      id: 1,
      name: 'Daily Fraud Summary',
      reportType: 'fraud_detection',
      frequency: 'Daily at 8:00 AM',
      recipients: ['admin@fraudguard.com', 'analyst@fraudguard.com'],
      format: 'PDF',
      status: 'active',
      lastSent: '2025-09-09 08:00:00',
      nextRun: '2025-09-10 08:00:00'
    },
    {
      id: 2,
      name: 'Weekly Performance Report',
      reportType: 'performance_metrics',
      frequency: 'Weekly on Monday at 9:00 AM',
      recipients: ['manager@fraudguard.com'],
      format: 'Excel',
      status: 'active',
      lastSent: '2025-09-02 09:00:00',
      nextRun: '2025-09-09 09:00:00'
    },
    {
      id: 3,
      name: 'Monthly Compliance Report',
      reportType: 'compliance_summary',
      frequency: 'Monthly on 1st at 10:00 AM',
      recipients: ['compliance@fraudguard.com', 'legal@fraudguard.com'],
      format: 'PDF',
      status: 'paused',
      lastSent: '2025-08-01 10:00:00',
      nextRun: '2025-10-01 10:00:00'
    },
    {
      id: 4,
      name: 'Risk Assessment Digest',
      reportType: 'risk_assessment',
      frequency: 'Bi-weekly on Friday at 5:00 PM',
      recipients: ['risk@fraudguard.com'],
      format: 'Dashboard',
      status: 'active',
      lastSent: '2025-09-06 17:00:00',
      nextRun: '2025-09-20 17:00:00'
    }
  ];

  const reportTypeOptions = [
    { value: 'fraud_detection', label: 'Fraud Detection Analysis' },
    { value: 'performance_metrics', label: 'Performance Metrics' },
    { value: 'compliance_summary', label: 'Compliance Summary' },
    { value: 'risk_assessment', label: 'Risk Assessment' }
  ];

  const frequencyOptions = [
    { value: 'daily', label: 'Daily' },
    { value: 'weekly', label: 'Weekly' },
    { value: 'biweekly', label: 'Bi-weekly' },
    { value: 'monthly', label: 'Monthly' }
  ];

  const formatOptions = [
    { value: 'pdf', label: 'PDF' },
    { value: 'excel', label: 'Excel' },
    { value: 'csv', label: 'CSV' },
    { value: 'dashboard', label: 'Dashboard Link' }
  ];

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status) => {
    return status === 'active' ?'bg-success/10 text-success' :'bg-warning/10 text-warning';
  };

  const handleCreateSchedule = () => {
    if (!newSchedule?.name || !newSchedule?.reportType || !newSchedule?.frequency) {
      alert('Please fill in all required fields');
      return;
    }
    // Handle schedule creation
    setShowCreateModal(false);
    setNewSchedule({
      name: '',
      reportType: '',
      frequency: '',
      recipients: '',
      format: 'pdf'
    });
  };

  const toggleReportStatus = (reportId) => {
    // Handle status toggle
    console.log('Toggling status for report:', reportId);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-10 h-10 bg-warning/10 rounded-lg">
            <Icon name="Clock" size={20} color="var(--color-warning)" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-text-primary">Scheduled Reports</h2>
            <p className="text-sm text-text-secondary">Automated report delivery and management</p>
          </div>
        </div>
        <Button 
          variant="default" 
          iconName="Plus"
          onClick={() => setShowCreateModal(true)}
        >
          Schedule Report
        </Button>
      </div>
      <div className="space-y-4">
        {scheduledReports?.map((report) => (
          <div key={report?.id} className="border border-border rounded-lg p-4 hover:shadow-card transition-standard">
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="font-medium text-text-primary">{report?.name}</h3>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(report?.status)}`}>
                    {report?.status}
                  </span>
                  <span className="inline-flex items-center px-2 py-1 bg-muted rounded text-xs text-text-secondary">
                    {report?.format}
                  </span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                  <div>
                    <div className="text-text-secondary">Frequency</div>
                    <div className="text-text-primary font-medium">{report?.frequency}</div>
                  </div>
                  <div>
                    <div className="text-text-secondary">Recipients</div>
                    <div className="text-text-primary font-medium">{report?.recipients?.length} recipient(s)</div>
                  </div>
                  <div>
                    <div className="text-text-secondary">Last Sent</div>
                    <div className="text-text-primary font-medium">{formatDate(report?.lastSent)}</div>
                  </div>
                  <div>
                    <div className="text-text-secondary">Next Run</div>
                    <div className="text-text-primary font-medium">{formatDate(report?.nextRun)}</div>
                  </div>
                </div>

                <div className="mt-3">
                  <div className="text-text-secondary text-sm">Recipients:</div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {report?.recipients?.map((email, index) => (
                      <span key={index} className="inline-flex items-center px-2 py-1 bg-muted rounded text-xs text-text-secondary">
                        {email}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2 ml-4">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  iconName={report?.status === 'active' ? 'Pause' : 'Play'}
                  onClick={() => toggleReportStatus(report?.id)}
                />
                <Button variant="ghost" size="sm" iconName="Settings" />
                <Button variant="ghost" size="sm" iconName="Trash2" />
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Create Schedule Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card rounded-lg border border-border p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-text-primary">Schedule New Report</h3>
              <Button 
                variant="ghost" 
                size="sm" 
                iconName="X"
                onClick={() => setShowCreateModal(false)}
              />
            </div>

            <div className="space-y-4">
              <Input
                label="Report Name"
                value={newSchedule?.name}
                onChange={(e) => setNewSchedule(prev => ({ ...prev, name: e?.target?.value }))}
                placeholder="Enter report name"
                required
              />

              <Select
                label="Report Type"
                options={reportTypeOptions}
                value={newSchedule?.reportType}
                onChange={(value) => setNewSchedule(prev => ({ ...prev, reportType: value }))}
                placeholder="Select report type"
                required
              />

              <Select
                label="Frequency"
                options={frequencyOptions}
                value={newSchedule?.frequency}
                onChange={(value) => setNewSchedule(prev => ({ ...prev, frequency: value }))}
                placeholder="Select frequency"
                required
              />

              <Input
                label="Recipients"
                value={newSchedule?.recipients}
                onChange={(e) => setNewSchedule(prev => ({ ...prev, recipients: e?.target?.value }))}
                placeholder="Enter email addresses (comma separated)"
                description="Separate multiple emails with commas"
              />

              <Select
                label="Format"
                options={formatOptions}
                value={newSchedule?.format}
                onChange={(value) => setNewSchedule(prev => ({ ...prev, format: value }))}
              />
            </div>

            <div className="flex items-center justify-end space-x-3 mt-6">
              <Button 
                variant="outline"
                onClick={() => setShowCreateModal(false)}
              >
                Cancel
              </Button>
              <Button 
                variant="default"
                onClick={handleCreateSchedule}
              >
                Create Schedule
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ScheduledReports;