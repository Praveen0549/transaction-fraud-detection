import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const ExportManager = () => {
  const [selectedExports, setSelectedExports] = useState([]);

  const exportHistory = [
    {
      id: 1,
      name: 'Fraud Detection Report - September 2025',
      type: 'fraud_detection',
      format: 'PDF',
      size: '2.4 MB',
      createdAt: '2025-09-09 14:30:00',
      status: 'completed',
      downloadUrl: '#',
      expiresAt: '2025-09-16 14:30:00'
    },
    {
      id: 2,
      name: 'Transaction Data Export - Last 30 Days',
      type: 'transaction_data',
      format: 'CSV',
      size: '15.7 MB',
      createdAt: '2025-09-09 12:15:00',
      status: 'completed',
      downloadUrl: '#',
      expiresAt: '2025-09-16 12:15:00'
    },
    {
      id: 3,
      name: 'Risk Assessment Summary - Q3 2025',
      type: 'risk_assessment',
      format: 'Excel',
      size: '5.2 MB',
      createdAt: '2025-09-09 10:45:00',
      status: 'processing',
      downloadUrl: null,
      expiresAt: null
    },
    {
      id: 4,
      name: 'Compliance Report - August 2025',
      type: 'compliance',
      format: 'PDF',
      size: '3.8 MB',
      createdAt: '2025-09-08 16:20:00',
      status: 'completed',
      downloadUrl: '#',
      expiresAt: '2025-09-15 16:20:00'
    },
    {
      id: 5,
      name: 'Performance Metrics - Weekly Summary',
      type: 'performance',
      format: 'Dashboard',
      size: 'N/A',
      createdAt: '2025-09-08 09:30:00',
      status: 'failed',
      downloadUrl: null,
      expiresAt: null
    },
    {
      id: 6,
      name: 'Geographic Analysis - Global Overview',
      type: 'geographic',
      format: 'CSV',
      size: '8.9 MB',
      createdAt: '2025-09-07 15:10:00',
      status: 'completed',
      downloadUrl: '#',
      expiresAt: '2025-09-14 15:10:00'
    }
  ];

  const bulkActions = [
    { value: 'download_selected', label: 'Download Selected' },
    { value: 'delete_selected', label: 'Delete Selected' },
    { value: 'extend_expiry', label: 'Extend Expiry' }
  ];

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status) => {
    const colors = {
      'completed': 'bg-success/10 text-success',
      'processing': 'bg-warning/10 text-warning',
      'failed': 'bg-error/10 text-error'
    };
    return colors?.[status] || 'bg-muted text-text-secondary';
  };

  const getStatusIcon = (status) => {
    const icons = {
      'completed': 'CheckCircle',
      'processing': 'Clock',
      'failed': 'XCircle'
    };
    return icons?.[status] || 'Circle';
  };

  const getTypeIcon = (type) => {
    const icons = {
      'fraud_detection': 'Shield',
      'transaction_data': 'CreditCard',
      'risk_assessment': 'AlertTriangle',
      'compliance': 'FileCheck',
      'performance': 'TrendingUp',
      'geographic': 'MapPin'
    };
    return icons?.[type] || 'FileText';
  };

  const handleSelectExport = (exportId) => {
    setSelectedExports(prev => 
      prev?.includes(exportId) 
        ? prev?.filter(id => id !== exportId)
        : [...prev, exportId]
    );
  };

  const handleSelectAll = () => {
    const completedExports = exportHistory?.filter(exp => exp?.status === 'completed')?.map(exp => exp?.id);
    setSelectedExports(prev => 
      prev?.length === completedExports?.length ? [] : completedExports
    );
  };

  const handleBulkAction = (action) => {
    if (selectedExports?.length === 0) {
      alert('Please select exports to perform bulk actions');
      return;
    }
    console.log('Performing bulk action:', action, 'on exports:', selectedExports);
  };

  const isExpiringSoon = (expiresAt) => {
    if (!expiresAt) return false;
    const expiryDate = new Date(expiresAt);
    const now = new Date();
    const hoursUntilExpiry = (expiryDate - now) / (1000 * 60 * 60);
    return hoursUntilExpiry <= 24 && hoursUntilExpiry > 0;
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-10 h-10 bg-secondary/10 rounded-lg">
            <Icon name="Download" size={20} color="var(--color-secondary)" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-text-primary">Export Manager</h2>
            <p className="text-sm text-text-secondary">Download and manage exported reports</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Select
            options={bulkActions}
            placeholder="Bulk Actions"
            onChange={handleBulkAction}
            disabled={selectedExports?.length === 0}
            className="min-w-[150px]"
          />
          <Button variant="outline" iconName="RefreshCw" size="sm">
            Refresh
          </Button>
        </div>
      </div>
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-background rounded-lg p-4 border border-border">
          <div className="flex items-center space-x-2">
            <Icon name="FileText" size={16} color="var(--color-primary)" />
            <span className="text-sm text-text-secondary">Total Exports</span>
          </div>
          <div className="text-2xl font-semibold text-text-primary mt-1">{exportHistory?.length}</div>
        </div>
        <div className="bg-background rounded-lg p-4 border border-border">
          <div className="flex items-center space-x-2">
            <Icon name="CheckCircle" size={16} color="var(--color-success)" />
            <span className="text-sm text-text-secondary">Completed</span>
          </div>
          <div className="text-2xl font-semibold text-text-primary mt-1">
            {exportHistory?.filter(exp => exp?.status === 'completed')?.length}
          </div>
        </div>
        <div className="bg-background rounded-lg p-4 border border-border">
          <div className="flex items-center space-x-2">
            <Icon name="Clock" size={16} color="var(--color-warning)" />
            <span className="text-sm text-text-secondary">Processing</span>
          </div>
          <div className="text-2xl font-semibold text-text-primary mt-1">
            {exportHistory?.filter(exp => exp?.status === 'processing')?.length}
          </div>
        </div>
        <div className="bg-background rounded-lg p-4 border border-border">
          <div className="flex items-center space-x-2">
            <Icon name="HardDrive" size={16} color="var(--color-text-secondary)" />
            <span className="text-sm text-text-secondary">Total Size</span>
          </div>
          <div className="text-2xl font-semibold text-text-primary mt-1">36.0 MB</div>
        </div>
      </div>
      {/* Export List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between pb-3 border-b border-border">
          <label className="flex items-center space-x-2 cursor-pointer">
            <input
              type="checkbox"
              checked={selectedExports?.length === exportHistory?.filter(exp => exp?.status === 'completed')?.length}
              onChange={handleSelectAll}
              className="w-4 h-4 text-primary border-border rounded focus:ring-primary"
            />
            <span className="text-sm font-medium text-text-primary">Select All Available</span>
          </label>
          <div className="text-sm text-text-secondary">
            {selectedExports?.length} of {exportHistory?.filter(exp => exp?.status === 'completed')?.length} selected
          </div>
        </div>

        {exportHistory?.map((exportItem) => (
          <div key={exportItem?.id} className="border border-border rounded-lg p-4 hover:shadow-card transition-standard">
            <div className="flex items-start space-x-4">
              {exportItem?.status === 'completed' && (
                <input
                  type="checkbox"
                  checked={selectedExports?.includes(exportItem?.id)}
                  onChange={() => handleSelectExport(exportItem?.id)}
                  className="w-4 h-4 text-primary border-border rounded focus:ring-primary mt-1"
                />
              )}
              
              <div className="flex items-center justify-center w-10 h-10 bg-muted rounded-lg flex-shrink-0">
                <Icon name={getTypeIcon(exportItem?.type)} size={18} color="var(--color-text-secondary)" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="font-medium text-text-primary truncate">{exportItem?.name}</h3>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(exportItem?.status)}`}>
                    <Icon name={getStatusIcon(exportItem?.status)} size={12} className="mr-1" />
                    {exportItem?.status}
                  </span>
                  <span className="inline-flex items-center px-2 py-1 bg-muted rounded text-xs text-text-secondary">
                    {exportItem?.format}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-text-secondary">Created</div>
                    <div className="text-text-primary font-medium">{formatDate(exportItem?.createdAt)}</div>
                  </div>
                  <div>
                    <div className="text-text-secondary">Size</div>
                    <div className="text-text-primary font-medium">{exportItem?.size}</div>
                  </div>
                  <div>
                    <div className="text-text-secondary">Expires</div>
                    <div className={`font-medium ${isExpiringSoon(exportItem?.expiresAt) ? 'text-warning' : 'text-text-primary'}`}>
                      {exportItem?.expiresAt ? formatDate(exportItem?.expiresAt) : 'N/A'}
                    </div>
                  </div>
                </div>

                {isExpiringSoon(exportItem?.expiresAt) && (
                  <div className="mt-2 flex items-center space-x-2 text-warning">
                    <Icon name="AlertTriangle" size={14} />
                    <span className="text-xs">Expires within 24 hours</span>
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-2 flex-shrink-0">
                {exportItem?.status === 'completed' && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    iconName="Download"
                    onClick={() => window.open(exportItem?.downloadUrl, '_blank')}
                  >
                    Download
                  </Button>
                )}
                {exportItem?.status === 'processing' && (
                  <Button variant="ghost" size="sm" iconName="X">
                    Cancel
                  </Button>
                )}
                {exportItem?.status === 'failed' && (
                  <Button variant="outline" size="sm" iconName="RefreshCw">
                    Retry
                  </Button>
                )}
                <Button variant="ghost" size="sm" iconName="Trash2" />
              </div>
            </div>
          </div>
        ))}
      </div>
      {exportHistory?.length === 0 && (
        <div className="text-center py-12">
          <Icon name="FileX" size={48} color="var(--color-text-secondary)" className="mx-auto mb-4" />
          <h3 className="text-lg font-medium text-text-primary mb-2">No exports found</h3>
          <p className="text-text-secondary">Generate your first report to see exports here</p>
        </div>
      )}
    </div>
  );
};

export default ExportManager;