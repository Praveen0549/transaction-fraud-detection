import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReportTemplates = ({ onSelectTemplate }) => {
  const templates = [
    {
      id: 'daily_fraud_summary',
      name: 'Daily Fraud Summary',
      description: 'Comprehensive daily overview of fraud detection activities and key metrics',
      icon: 'Calendar',
      frequency: 'Daily',
      lastGenerated: '2025-09-09 08:30:00',
      metrics: ['Fraud Rate', 'Transaction Volume', 'False Positives'],
      format: 'PDF'
    },
    {
      id: 'weekly_performance',
      name: 'Weekly Performance Report',
      description: 'Weekly analysis of system performance and detection accuracy',
      icon: 'TrendingUp',
      frequency: 'Weekly',
      lastGenerated: '2025-09-02 09:15:00',
      metrics: ['Detection Accuracy', 'Response Time', 'System Health'],
      format: 'Excel'
    },
    {
      id: 'monthly_compliance',
      name: 'Monthly Compliance Report',
      description: 'Regulatory compliance summary with audit trail and documentation',
      icon: 'Shield',
      frequency: 'Monthly',
      lastGenerated: '2025-08-31 17:45:00',
      metrics: ['Compliance Score', 'Audit Trail', 'Risk Assessment'],
      format: 'PDF'
    },
    {
      id: 'quarterly_trends',
      name: 'Quarterly Trend Analysis',
      description: 'Comprehensive quarterly analysis of fraud patterns and trends',
      icon: 'BarChart3',
      frequency: 'Quarterly',
      lastGenerated: '2025-06-30 16:20:00',
      metrics: ['Trend Analysis', 'Pattern Recognition', 'Forecasting'],
      format: 'Dashboard'
    },
    {
      id: 'custom_investigation',
      name: 'Investigation Report',
      description: 'Detailed investigation report for specific fraud cases or incidents',
      icon: 'Search',
      frequency: 'On-demand',
      lastGenerated: '2025-09-08 14:22:00',
      metrics: ['Case Details', 'Evidence', 'Timeline'],
      format: 'PDF'
    },
    {
      id: 'risk_assessment',
      name: 'Risk Assessment Report',
      description: 'Comprehensive risk analysis with recommendations and mitigation strategies',
      icon: 'AlertTriangle',
      frequency: 'Bi-weekly',
      lastGenerated: '2025-09-01 11:30:00',
      metrics: ['Risk Scores', 'Vulnerability Analysis', 'Recommendations'],
      format: 'Excel'
    }
  ];

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getFrequencyColor = (frequency) => {
    const colors = {
      'Daily': 'bg-success/10 text-success',
      'Weekly': 'bg-primary/10 text-primary',
      'Monthly': 'bg-warning/10 text-warning',
      'Quarterly': 'bg-accent/10 text-accent',
      'Bi-weekly': 'bg-secondary/10 text-secondary',
      'On-demand': 'bg-muted text-text-secondary'
    };
    return colors?.[frequency] || 'bg-muted text-text-secondary';
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-10 h-10 bg-accent/10 rounded-lg">
            <Icon name="FileStack" size={20} color="var(--color-accent)" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-text-primary">Report Templates</h2>
            <p className="text-sm text-text-secondary">Pre-configured reports for quick generation</p>
          </div>
        </div>
        <Button variant="outline" iconName="Plus" size="sm">
          Create Template
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {templates?.map((template) => (
          <div key={template?.id} className="border border-border rounded-lg p-4 hover:shadow-card transition-standard">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-8 h-8 bg-muted rounded-lg">
                  <Icon name={template?.icon} size={16} color="var(--color-text-secondary)" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-text-primary truncate">{template?.name}</h3>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getFrequencyColor(template?.frequency)}`}>
                    {template?.frequency}
                  </span>
                </div>
              </div>
            </div>

            <p className="text-sm text-text-secondary mb-4 line-clamp-2">
              {template?.description}
            </p>

            <div className="space-y-3">
              <div>
                <div className="text-xs font-medium text-text-secondary mb-1">Metrics Included</div>
                <div className="flex flex-wrap gap-1">
                  {template?.metrics?.slice(0, 2)?.map((metric) => (
                    <span key={metric} className="inline-flex items-center px-2 py-1 bg-muted rounded text-xs text-text-secondary">
                      {metric}
                    </span>
                  ))}
                  {template?.metrics?.length > 2 && (
                    <span className="inline-flex items-center px-2 py-1 bg-muted rounded text-xs text-text-secondary">
                      +{template?.metrics?.length - 2} more
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-text-secondary">
                <span>Format: {template?.format}</span>
                <span>Last: {formatDate(template?.lastGenerated)}</span>
              </div>
            </div>

            <div className="flex items-center space-x-2 mt-4 pt-4 border-t border-border">
              <Button 
                variant="outline" 
                size="sm" 
                iconName="Play"
                onClick={() => onSelectTemplate(template)}
                className="flex-1"
              >
                Generate
              </Button>
              <Button variant="ghost" size="sm" iconName="Settings" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ReportTemplates;