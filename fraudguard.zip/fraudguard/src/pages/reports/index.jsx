import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import ReportBuilder from './components/ReportBuilder';
import ReportTemplates from './components/ReportTemplates';
import AnalyticsCharts from './components/AnalyticsCharts';
import ScheduledReports from './components/ScheduledReports';
import ExportManager from './components/ExportManager';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const Reports = () => {
  const [activeTab, setActiveTab] = useState('builder');
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);

  const tabs = [
    { id: 'builder', label: 'Report Builder', icon: 'FileText' },
    { id: 'templates', label: 'Templates', icon: 'FileStack' },
    { id: 'analytics', label: 'Analytics', icon: 'BarChart3' },
    { id: 'scheduled', label: 'Scheduled', icon: 'Clock' },
    { id: 'exports', label: 'Exports', icon: 'Download' }
  ];

  const handleGenerateReport = async (reportConfig) => {
    setIsGeneratingReport(true);
    try {
      // Simulate report generation
      await new Promise(resolve => setTimeout(resolve, 2000));
      alert(`Report "${reportConfig?.reportType}" generated successfully! Check the Exports tab to download.`);
    } catch (error) {
      alert('Failed to generate report. Please try again.');
    } finally {
      setIsGeneratingReport(false);
    }
  };

  const handleSelectTemplate = (template) => {
    setActiveTab('builder');
    // Pre-populate builder with template data
    alert(`Template "${template?.name}" loaded in Report Builder`);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'builder':
        return <ReportBuilder onGenerateReport={handleGenerateReport} />;
      case 'templates':
        return <ReportTemplates onSelectTemplate={handleSelectTemplate} />;
      case 'analytics':
        return <AnalyticsCharts />;
      case 'scheduled':
        return <ScheduledReports />;
      case 'exports':
        return <ExportManager />;
      default:
        return <ReportBuilder onGenerateReport={handleGenerateReport} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Reports - FraudGuard</title>
        <meta name="description" content="Comprehensive fraud detection analytics and regulatory reporting capabilities for compliance and performance analysis" />
      </Helmet>
      <Header userRole="analyst" alertCount={3} />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-semibold text-text-primary mb-2">Reports & Analytics</h1>
                <p className="text-text-secondary">
                  Comprehensive fraud detection analytics and regulatory reporting capabilities
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <div className="hidden lg:flex items-center space-x-2 px-3 py-2 bg-success/10 rounded-lg">
                  <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
                  <span className="text-sm text-success font-medium">Real-time Data</span>
                </div>
                <Button variant="outline" iconName="RefreshCw" size="sm">
                  Refresh Data
                </Button>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-card rounded-lg border border-border p-6">
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg">
                  <Icon name="FileText" size={24} color="var(--color-primary)" />
                </div>
                <div>
                  <div className="text-2xl font-semibold text-text-primary">247</div>
                  <div className="text-sm text-text-secondary">Reports Generated</div>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg border border-border p-6">
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-12 h-12 bg-success/10 rounded-lg">
                  <Icon name="TrendingUp" size={24} color="var(--color-success)" />
                </div>
                <div>
                  <div className="text-2xl font-semibold text-text-primary">98.7%</div>
                  <div className="text-sm text-text-secondary">Detection Accuracy</div>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg border border-border p-6">
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-12 h-12 bg-warning/10 rounded-lg">
                  <Icon name="Clock" size={24} color="var(--color-warning)" />
                </div>
                <div>
                  <div className="text-2xl font-semibold text-text-primary">12</div>
                  <div className="text-sm text-text-secondary">Scheduled Reports</div>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg border border-border p-6">
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-12 h-12 bg-secondary/10 rounded-lg">
                  <Icon name="Download" size={24} color="var(--color-secondary)" />
                </div>
                <div>
                  <div className="text-2xl font-semibold text-text-primary">156</div>
                  <div className="text-sm text-text-secondary">Downloads This Month</div>
                </div>
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="bg-card rounded-lg border border-border mb-8">
            <div className="border-b border-border">
              <nav className="flex space-x-8 px-6" aria-label="Reports navigation">
                {tabs?.map((tab) => (
                  <button
                    key={tab?.id}
                    onClick={() => setActiveTab(tab?.id)}
                    className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-micro ${
                      activeTab === tab?.id
                        ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-border'
                    }`}
                  >
                    <Icon name={tab?.icon} size={18} />
                    <span>{tab?.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Tab Content */}
          <div className="space-y-8">
            {renderTabContent()}
          </div>

          {/* Loading Overlay */}
          {isGeneratingReport && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-card rounded-lg border border-border p-8 max-w-sm w-full mx-4">
                <div className="text-center">
                  <div className="flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mx-auto mb-4">
                    <Icon name="FileText" size={32} color="var(--color-primary)" className="animate-pulse" />
                  </div>
                  <h3 className="text-lg font-semibold text-text-primary mb-2">Generating Report</h3>
                  <p className="text-text-secondary mb-4">Please wait while we compile your report data...</p>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-primary h-2 rounded-full animate-pulse" style={{ width: '60%' }} />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Reports;