import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import RegistrationForm from './components/RegistrationForm';
import TrustSignals from './components/TrustSignals';
import RegistrationSteps from './components/RegistrationSteps';

const Register = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const [registeredUser, setRegisteredUser] = useState(null);

  const handleRegistration = async (formData) => {
    setLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock registration success
      const userData = {
        id: Date.now(),
        name: `${formData?.firstName} ${formData?.lastName}`,
        email: formData?.email,
        role: formData?.role,
        status: formData?.role === 'customer' ? 'active' : 'pending_approval',
        createdAt: new Date()?.toISOString()
      };
      
      setRegisteredUser(userData);
      setRegistrationSuccess(true);
      
      // Redirect after success message
      setTimeout(() => {
        if (userData?.role === 'customer') {
          navigate('/login', { 
            state: { 
              message: 'Registration successful! Please check your email to verify your account.',
              email: userData?.email
            }
          });
        } else {
          navigate('/login', { 
            state: { 
              message: 'Registration submitted! Your account is pending approval. You will receive an email once approved.',
              email: userData?.email
            }
          });
        }
      }, 3000);
      
    } catch (error) {
      console.error('Registration failed:', error);
      // Handle error state here
    } finally {
      setLoading(false);
    }
  };

  if (registrationSuccess) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-surface rounded-2xl shadow-card border border-border p-8 text-center">
            <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="CheckCircle" size={32} color="var(--color-success)" />
            </div>
            
            <h2 className="text-2xl font-semibold text-text-primary mb-2">
              Registration Successful!
            </h2>
            
            <p className="text-text-secondary mb-6">
              {registeredUser?.role === 'customer' ?'Please check your email to verify your account and complete the setup process.' :'Your account has been submitted for approval. You will receive an email notification once your account is approved by our administrators.'
              }
            </p>
            
            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <span className="text-text-secondary">Email:</span>
                <span className="font-medium text-text-primary">{registeredUser?.email}</span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <span className="text-text-secondary">Role:</span>
                <span className="font-medium text-text-primary capitalize">
                  {registeredUser?.role?.replace('_', ' ')}
                </span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <span className="text-text-secondary">Status:</span>
                <span className={`font-medium capitalize ${
                  registeredUser?.status === 'active' ? 'text-success' : 'text-warning'
                }`}>
                  {registeredUser?.status?.replace('_', ' ')}
                </span>
              </div>
            </div>
            
            <div className="mt-6 text-xs text-text-secondary">
              Redirecting to login page in a few seconds...
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-surface border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
                <Icon name="Shield" size={20} color="white" />
              </div>
              <span className="text-xl font-semibold text-text-primary">
                FraudGuard
              </span>
            </div>
            
            <div className="flex items-center space-x-2 text-sm text-text-secondary">
              <Icon name="Clock" size={16} />
              <span>Registration takes ~5 minutes</span>
            </div>
          </div>
        </div>
      </div>
      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Registration Form */}
          <div className="lg:col-span-2">
            <div className="bg-surface rounded-2xl shadow-card border border-border p-6 lg:p-8">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-text-primary mb-2">
                  Create Your Account
                </h1>
                <p className="text-text-secondary">
                  Join FraudGuard to protect your financial transactions with advanced AI-powered fraud detection.
                </p>
              </div>

              <RegistrationForm onSubmit={handleRegistration} loading={loading} />
            </div>
          </div>

          {/* Right Column - Trust Signals & Steps */}
          <div className="space-y-6">
            {/* Registration Steps */}
            <div className="bg-surface rounded-2xl shadow-card border border-border p-6">
              <RegistrationSteps currentStep={1} />
            </div>

            {/* Trust Signals */}
            <div className="bg-surface rounded-2xl shadow-card border border-border p-6">
              <TrustSignals />
            </div>

            {/* Support Information */}
            <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6">
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0 w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Icon name="HelpCircle" size={18} color="var(--color-primary)" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-text-primary mb-2">
                    Need Help?
                  </h3>
                  <p className="text-xs text-text-secondary mb-3">
                    Our support team is available 24/7 to assist you with the registration process.
                  </p>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center space-x-2">
                      <Icon name="Mail" size={14} color="var(--color-text-secondary)" />
                      <span className="text-text-secondary">support@fraudguard.com</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Icon name="Phone" size={14} color="var(--color-text-secondary)" />
                      <span className="text-text-secondary">+1 (555) 123-4567</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Footer */}
      <footer className="bg-surface border-t border-border mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-6 text-sm text-text-secondary">
              <a href="#" className="hover:text-text-primary transition-micro">Terms of Service</a>
              <a href="#" className="hover:text-text-primary transition-micro">Privacy Policy</a>
              <a href="#" className="hover:text-text-primary transition-micro">Security</a>
            </div>
            
            <div className="text-sm text-text-secondary">
              © {new Date()?.getFullYear()} FraudGuard. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Register;