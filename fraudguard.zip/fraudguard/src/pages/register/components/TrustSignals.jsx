import React from 'react';
import Icon from '../../../components/AppIcon';

const TrustSignals = () => {
  const securityFeatures = [
    {
      icon: 'Shield',
      title: 'Bank-Grade Security',
      description: '256-bit SSL encryption protects your data'
    },
    {
      icon: 'Lock',
      title: 'Data Protection',
      description: 'GDPR compliant with advanced privacy controls'
    },
    {
      icon: 'CheckCircle',
      title: 'Verified Platform',
      description: 'SOC 2 Type II certified security standards'
    },
    {
      icon: 'Eye',
      title: 'Fraud Monitoring',
      description: 'Real-time protection against suspicious activity'
    }
  ];

  const certifications = [
    {
      name: 'PCI DSS',
      description: 'Payment Card Industry Data Security Standard',
      icon: 'CreditCard'
    },
    {
      name: 'ISO 27001',
      description: 'Information Security Management',
      icon: 'FileCheck'
    },
    {
      name: 'SOC 2',
      description: 'Service Organization Control 2',
      icon: 'Building'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Security Features */}
      <div>
        <h3 className="text-lg font-semibold text-text-primary mb-4">
          Your Security is Our Priority
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {securityFeatures?.map((feature, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 bg-surface rounded-lg border border-border">
              <div className="flex-shrink-0 w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                <Icon name={feature?.icon} size={16} color="var(--color-primary)" />
              </div>
              <div>
                <h4 className="text-sm font-medium text-text-primary">{feature?.title}</h4>
                <p className="text-xs text-text-secondary mt-1">{feature?.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Compliance Certifications */}
      <div>
        <h3 className="text-lg font-semibold text-text-primary mb-4">
          Compliance & Certifications
        </h3>
        <div className="space-y-3">
          {certifications?.map((cert, index) => (
            <div key={index} className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
              <div className="flex-shrink-0 w-6 h-6 bg-success/10 rounded flex items-center justify-center">
                <Icon name={cert?.icon} size={14} color="var(--color-success)" />
              </div>
              <div>
                <span className="text-sm font-medium text-text-primary">{cert?.name}</span>
                <p className="text-xs text-text-secondary">{cert?.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Trust Indicators */}
      <div className="bg-success/5 border border-success/20 rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-2">
          <Icon name="ShieldCheck" size={20} color="var(--color-success)" />
          <span className="text-sm font-medium text-success">Trusted by 10,000+ Users</span>
        </div>
        <p className="text-xs text-text-secondary">
          Join thousands of financial institutions and individuals who trust FraudGuard 
          for their transaction security needs.
        </p>
      </div>
      {/* Data Encryption Notice */}
      <div className="text-center p-4 bg-primary/5 rounded-lg border border-primary/20">
        <Icon name="Lock" size={24} color="var(--color-primary)" className="mx-auto mb-2" />
        <p className="text-xs text-text-secondary">
          All data is encrypted in transit and at rest using industry-standard AES-256 encryption.
          Your personal information is never shared with third parties.
        </p>
      </div>
    </div>
  );
};

export default TrustSignals;