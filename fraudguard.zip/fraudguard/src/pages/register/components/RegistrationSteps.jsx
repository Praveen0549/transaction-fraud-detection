import React from 'react';
import Icon from '../../../components/AppIcon';

const RegistrationSteps = ({ currentStep = 1 }) => {
  const steps = [
    {
      number: 1,
      title: 'Create Account',
      description: 'Fill in your personal details and choose account type',
      icon: 'UserPlus'
    },
    {
      number: 2,
      title: 'Email Verification',
      description: 'Verify your email address to activate your account',
      icon: 'Mail'
    },
    {
      number: 3,
      title: 'Identity Validation',
      description: 'Complete identity verification for enhanced security',
      icon: 'FileCheck'
    },
    {
      number: 4,
      title: 'Account Approval',
      description: 'Admin approval required for analyst and admin roles',
      icon: 'CheckCircle'
    }
  ];

  const getStepStatus = (stepNumber) => {
    if (stepNumber < currentStep) return 'completed';
    if (stepNumber === currentStep) return 'current';
    return 'pending';
  };

  const getStepIcon = (step, status) => {
    if (status === 'completed') return 'CheckCircle';
    if (status === 'current') return step?.icon;
    return step?.icon;
  };

  const getStepColor = (status) => {
    switch (status) {
      case 'completed':
        return 'var(--color-success)';
      case 'current':
        return 'var(--color-primary)';
      default:
        return 'var(--color-text-secondary)';
    }
  };

  const getStepBgColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-success/10';
      case 'current':
        return 'bg-primary/10';
      default:
        return 'bg-muted';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-text-primary mb-2">
          Registration Process
        </h3>
        <p className="text-sm text-text-secondary">
          Follow these steps to complete your account setup
        </p>
      </div>
      <div className="space-y-4">
        {steps?.map((step, index) => {
          const status = getStepStatus(step?.number);
          const isLast = index === steps?.length - 1;

          return (
            <div key={step?.number} className="relative">
              <div className="flex items-start space-x-4">
                {/* Step Icon */}
                <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${getStepBgColor(status)} border-2 ${
                  status === 'completed' ? 'border-success' : 
                  status === 'current' ? 'border-primary' : 'border-border'
                }`}>
                  <Icon 
                    name={getStepIcon(step, status)} 
                    size={18} 
                    color={getStepColor(status)} 
                  />
                </div>

                {/* Step Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className={`text-sm font-medium ${
                      status === 'current' ? 'text-primary' : 
                      status === 'completed' ? 'text-success' : 'text-text-secondary'
                    }`}>
                      {step?.title}
                    </h4>
                    {status === 'current' && (
                      <span className="px-2 py-1 text-xs font-medium bg-primary text-primary-foreground rounded-full">
                        Current
                      </span>
                    )}
                    {status === 'completed' && (
                      <span className="px-2 py-1 text-xs font-medium bg-success text-success-foreground rounded-full">
                        Complete
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-text-secondary">
                    {step?.description}
                  </p>
                </div>
              </div>
              {/* Connecting Line */}
              {!isLast && (
                <div className="absolute left-5 top-10 w-0.5 h-6 bg-border" />
              )}
            </div>
          );
        })}
      </div>
      {/* Additional Information */}
      <div className="bg-accent/5 border border-accent/20 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={16} color="var(--color-accent)" className="mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="text-sm font-medium text-text-primary mb-1">
              Account Approval Process
            </h4>
            <p className="text-xs text-text-secondary">
              Customer accounts are activated immediately after email verification. 
              Analyst and Administrator roles require manual approval which typically 
              takes 1-2 business days.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegistrationSteps;