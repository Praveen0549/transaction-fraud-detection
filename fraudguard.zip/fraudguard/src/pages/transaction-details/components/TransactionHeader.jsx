import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TransactionHeader = ({ transaction, onBack, onApprove, onReject, onEscalate }) => {
  const getRiskLevelColor = (riskLevel) => {
    switch (riskLevel) {
      case 'high':
        return 'text-error bg-red-50 border-red-200';
      case 'medium':
        return 'text-warning bg-yellow-50 border-yellow-200';
      case 'low':
        return 'text-success bg-green-50 border-green-200';
      default:
        return 'text-text-secondary bg-muted border-border';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved':
        return 'text-success bg-green-50 border-green-200';
      case 'rejected':
        return 'text-error bg-red-50 border-red-200';
      case 'pending':
        return 'text-warning bg-yellow-50 border-yellow-200';
      case 'escalated':
        return 'text-accent bg-orange-50 border-orange-200';
      default:
        return 'text-text-secondary bg-muted border-border';
    }
  };

  return (
    <div className="bg-card border-b border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="text-text-secondary hover:text-text-primary"
          >
            <Icon name="ArrowLeft" size={20} />
          </Button>
          <div>
            <h1 className="text-2xl font-semibold text-text-primary">
              Transaction Details
            </h1>
            <p className="text-sm text-text-secondary mt-1">
              ID: {transaction?.id}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className={`px-3 py-1 rounded-full text-sm font-medium border ${getRiskLevelColor(transaction?.riskLevel)}`}>
            {transaction?.riskLevel?.charAt(0)?.toUpperCase() + transaction?.riskLevel?.slice(1)} Risk
          </div>
          <div className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(transaction?.status)}`}>
            {transaction?.status?.charAt(0)?.toUpperCase() + transaction?.status?.slice(1)}
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-surface p-4 rounded-lg border border-border">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="DollarSign" size={16} color="var(--color-primary)" />
            <span className="text-sm font-medium text-text-secondary">Amount</span>
          </div>
          <p className="text-2xl font-semibold text-text-primary">
            ${transaction?.amount?.toLocaleString()}
          </p>
        </div>

        <div className="bg-surface p-4 rounded-lg border border-border">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="TrendingUp" size={16} color="var(--color-warning)" />
            <span className="text-sm font-medium text-text-secondary">Fraud Probability</span>
          </div>
          <p className="text-2xl font-semibold text-warning">
            {(transaction?.fraudProbability * 100)?.toFixed(1)}%
          </p>
        </div>

        <div className="bg-surface p-4 rounded-lg border border-border">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Clock" size={16} color="var(--color-accent)" />
            <span className="text-sm font-medium text-text-secondary">Processing Time</span>
          </div>
          <p className="text-2xl font-semibold text-text-primary">
            {transaction?.processingTime}ms
          </p>
        </div>
      </div>
      {transaction?.status === 'pending' && (
        <div className="flex items-center space-x-3">
          <Button
            variant="success"
            iconName="Check"
            iconPosition="left"
            onClick={onApprove}
          >
            Approve
          </Button>
          <Button
            variant="destructive"
            iconName="X"
            iconPosition="left"
            onClick={onReject}
          >
            Reject
          </Button>
          <Button
            variant="outline"
            iconName="AlertTriangle"
            iconPosition="left"
            onClick={onEscalate}
          >
            Escalate
          </Button>
        </div>
      )}
    </div>
  );
};

export default TransactionHeader;