import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const CommentsSection = ({ comments, onAddComment }) => {
  const [newComment, setNewComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e?.preventDefault();
    if (!newComment?.trim()) return;

    setIsSubmitting(true);
    try {
      await onAddComment(newComment?.trim());
      setNewComment('');
    } catch (error) {
      console.error('Failed to add comment:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getUserRoleColor = (role) => {
    switch (role) {
      case 'admin':
        return 'text-error bg-red-50 border-red-200';
      case 'analyst':
        return 'text-primary bg-blue-50 border-blue-200';
      case 'system':
        return 'text-accent bg-orange-50 border-orange-200';
      default:
        return 'text-text-secondary bg-muted border-border';
    }
  };

  const getUserAvatar = (user) => {
    if (user?.avatar) {
      return (
        <img
          src={user?.avatar}
          alt={user?.name}
          className="w-8 h-8 rounded-full object-cover"
        />
      );
    }
    
    return (
      <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
        <span className="text-xs font-medium text-primary-foreground">
          {user?.name?.charAt(0)?.toUpperCase()}
        </span>
      </div>
    );
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <h2 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
        <Icon name="MessageSquare" size={20} color="var(--color-primary)" />
        <span>Investigation Notes & Comments</span>
        <span className="text-sm font-normal text-text-secondary">
          ({comments?.length})
        </span>
      </h2>
      {/* Add Comment Form */}
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="space-y-3">
          <Input
            type="text"
            placeholder="Add investigation note or comment..."
            value={newComment}
            onChange={(e) => setNewComment(e?.target?.value)}
            className="w-full"
            disabled={isSubmitting}
          />
          <div className="flex justify-end">
            <Button
              type="submit"
              variant="default"
              size="sm"
              iconName="Send"
              iconPosition="right"
              disabled={!newComment?.trim() || isSubmitting}
              loading={isSubmitting}
            >
              Add Comment
            </Button>
          </div>
        </div>
      </form>
      {/* Comments List */}
      <div className="space-y-4">
        {comments?.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="MessageSquare" size={48} color="var(--color-text-secondary)" className="mx-auto mb-3 opacity-50" />
            <p className="text-text-secondary">No comments yet</p>
            <p className="text-sm text-text-secondary mt-1">
              Add the first investigation note or comment
            </p>
          </div>
        ) : (
          comments?.map((comment) => (
            <div key={comment?.id} className="bg-surface p-4 rounded-lg border border-border">
              <div className="flex items-start space-x-3">
                {getUserAvatar(comment?.user)}
                
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="font-medium text-text-primary">
                      {comment?.user?.name}
                    </span>
                    <span className={`px-2 py-0.5 text-xs font-medium rounded border ${getUserRoleColor(comment?.user?.role)}`}>
                      {comment?.user?.role?.charAt(0)?.toUpperCase() + comment?.user?.role?.slice(1)}
                    </span>
                    <span className="text-xs text-text-secondary">
                      {formatDate(comment?.timestamp)}
                    </span>
                  </div>
                  
                  <p className="text-text-primary text-sm leading-relaxed mb-3">
                    {comment?.content}
                  </p>

                  {/* Comment Actions */}
                  {comment?.actions && comment?.actions?.length > 0 && (
                    <div className="bg-muted p-3 rounded border border-border">
                      <h5 className="text-xs font-medium text-text-secondary mb-2 flex items-center space-x-1">
                        <Icon name="Activity" size={12} />
                        <span>Actions Taken</span>
                      </h5>
                      <div className="space-y-1">
                        {comment?.actions?.map((action, index) => (
                          <div key={index} className="flex items-center space-x-2 text-xs">
                            <Icon 
                              name={action?.type === 'approve' ? 'Check' : action?.type === 'reject' ? 'X' : 'AlertTriangle'} 
                              size={12} 
                              color={`var(--color-${action?.type === 'approve' ? 'success' : action?.type === 'reject' ? 'error' : 'warning'})`}
                            />
                            <span className="text-text-primary">{action?.description}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Comment Attachments */}
                  {comment?.attachments && comment?.attachments?.length > 0 && (
                    <div className="mt-3">
                      <h5 className="text-xs font-medium text-text-secondary mb-2">Attachments</h5>
                      <div className="flex flex-wrap gap-2">
                        {comment?.attachments?.map((attachment, index) => (
                          <div key={index} className="flex items-center space-x-2 bg-muted px-2 py-1 rounded text-xs">
                            <Icon name="Paperclip" size={12} />
                            <span className="text-text-primary">{attachment?.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      {/* Comment Statistics */}
      {comments?.length > 0 && (
        <div className="mt-6 pt-4 border-t border-border">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-lg font-semibold text-text-primary">
                {comments?.length}
              </p>
              <p className="text-xs text-text-secondary">Total Comments</p>
            </div>
            <div>
              <p className="text-lg font-semibold text-text-primary">
                {comments?.filter(c => c?.user?.role === 'analyst')?.length}
              </p>
              <p className="text-xs text-text-secondary">Analyst Notes</p>
            </div>
            <div>
              <p className="text-lg font-semibold text-text-primary">
                {comments?.filter(c => c?.actions && c?.actions?.length > 0)?.length}
              </p>
              <p className="text-xs text-text-secondary">With Actions</p>
            </div>
            <div>
              <p className="text-lg font-semibold text-text-primary">
                {comments?.filter(c => c?.user?.role === 'system')?.length}
              </p>
              <p className="text-xs text-text-secondary">System Logs</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CommentsSection;