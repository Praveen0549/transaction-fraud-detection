import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const ActionModal = ({ isOpen, onClose, action, transaction, onConfirm }) => {
  const [justification, setJustification] = useState('');
  const [priority, setPriority] = useState('medium');
  const [assignee, setAssignee] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const priorityOptions = [
    { value: 'low', label: 'Low Priority' },
    { value: 'medium', label: 'Medium Priority' },
    { value: 'high', label: 'High Priority' },
    { value: 'critical', label: 'Critical Priority' }
  ];

  const assigneeOptions = [
    { value: 'auto', label: 'Auto-assign' },
    { value: 'john_doe', label: 'John Doe (Senior Analyst)' },
    { value: 'jane_smith', label: 'Jane Smith (Fraud Specialist)' },
    { value: 'mike_wilson', label: 'Mike Wilson (Team Lead)' }
  ];

  const handleSubmit = async (e) => {
    e?.preventDefault();
    if (!justification?.trim()) return;

    setIsSubmitting(true);
    try {
      await onConfirm({
        action,
        justification: justification?.trim(),
        priority: action === 'escalate' ? priority : undefined,
        assignee: action === 'escalate' ? assignee : undefined,
        timestamp: new Date()?.toISOString()
      });
      handleClose();
    } catch (error) {
      console.error('Failed to perform action:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setJustification('');
    setPriority('medium');
    setAssignee('');
    onClose();
  };

  const getActionConfig = () => {
    switch (action) {
      case 'approve':
        return {
          title: 'Approve Transaction',
          icon: 'Check',
          color: 'text-success',
          bgColor: 'bg-green-50',
          description: 'Mark this transaction as legitimate and approved.',
          buttonText: 'Approve Transaction',
          buttonVariant: 'success'
        };
      case 'reject':
        return {
          title: 'Reject Transaction',
          icon: 'X',
          color: 'text-error',
          bgColor: 'bg-red-50',
          description: 'Mark this transaction as fraudulent and reject it.',
          buttonText: 'Reject Transaction',
          buttonVariant: 'destructive'
        };
      case 'escalate':
        return {
          title: 'Escalate Transaction',
          icon: 'AlertTriangle',
          color: 'text-warning',
          bgColor: 'bg-yellow-50',
          description: 'Escalate this transaction for further investigation.',
          buttonText: 'Escalate Transaction',
          buttonVariant: 'warning'
        };
      default:
        return {
          title: 'Transaction Action',
          icon: 'Activity',
          color: 'text-text-primary',
          bgColor: 'bg-muted',
          description: 'Perform action on this transaction.',
          buttonText: 'Confirm Action',
          buttonVariant: 'default'
        };
    }
  };

  if (!isOpen) return null;

  const config = getActionConfig();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
      <div className="bg-card rounded-lg border border-border shadow-modal w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className={`p-6 border-b border-border ${config?.bgColor}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg bg-card border border-border`}>
                <Icon name={config?.icon} size={20} color={`var(--color-${config?.color?.replace('text-', '')})`} />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-text-primary">
                  {config?.title}
                </h2>
                <p className="text-sm text-text-secondary">
                  Transaction ID: {transaction?.id}
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="text-text-secondary hover:text-text-primary"
            >
              <Icon name="X" size={20} />
            </Button>
          </div>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6">
          <div className="mb-4">
            <p className="text-sm text-text-secondary mb-4">
              {config?.description}
            </p>

            {/* Transaction Summary */}
            <div className="bg-surface p-4 rounded-lg border border-border mb-4">
              <h4 className="font-medium text-text-primary mb-2">Transaction Summary</h4>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-text-secondary">Amount:</span>
                  <span className="text-text-primary font-medium ml-2">
                    ${transaction?.amount?.toLocaleString()}
                  </span>
                </div>
                <div>
                  <span className="text-text-secondary">Risk:</span>
                  <span className={`font-medium ml-2 ${transaction?.fraudProbability >= 0.7 ? 'text-error' : transaction?.fraudProbability >= 0.4 ? 'text-warning' : 'text-success'}`}>
                    {(transaction?.fraudProbability * 100)?.toFixed(1)}%
                  </span>
                </div>
                <div>
                  <span className="text-text-secondary">From:</span>
                  <span className="text-text-primary font-medium ml-2 truncate">
                    {transaction?.sender?.name}
                  </span>
                </div>
                <div>
                  <span className="text-text-secondary">To:</span>
                  <span className="text-text-primary font-medium ml-2 truncate">
                    {transaction?.receiver?.name}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Justification */}
          <div className="mb-4">
            <Input
              type="text"
              label="Justification"
              description="Provide a reason for this action"
              placeholder={`Enter reason for ${action}ing this transaction...`}
              value={justification}
              onChange={(e) => setJustification(e?.target?.value)}
              required
              disabled={isSubmitting}
            />
          </div>

          {/* Escalation Options */}
          {action === 'escalate' && (
            <div className="space-y-4 mb-4">
              <Select
                label="Priority Level"
                description="Set the priority for this escalation"
                options={priorityOptions}
                value={priority}
                onChange={setPriority}
                disabled={isSubmitting}
              />

              <Select
                label="Assign To"
                description="Choose who should handle this escalation"
                options={assigneeOptions}
                value={assignee}
                onChange={setAssignee}
                disabled={isSubmitting}
              />
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-border">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant={config?.buttonVariant}
              iconName={config?.icon}
              iconPosition="left"
              disabled={!justification?.trim() || isSubmitting}
              loading={isSubmitting}
            >
              {config?.buttonText}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ActionModal;