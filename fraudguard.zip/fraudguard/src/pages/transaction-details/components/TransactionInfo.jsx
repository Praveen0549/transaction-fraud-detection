import React from 'react';
import Icon from '../../../components/AppIcon';

const TransactionInfo = ({ transaction }) => {
  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const getTransactionTypeIcon = (type) => {
    switch (type) {
      case 'upi':
        return 'Smartphone';
      case 'card':
        return 'CreditCard';
      case 'bank_transfer':
        return 'Building2';
      case 'wallet':
        return 'Wallet';
      default:
        return 'ArrowRightLeft';
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <h2 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
        <Icon name="Info" size={20} color="var(--color-primary)" />
        <span>Transaction Information</span>
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-text-secondary">Transaction ID</label>
            <p className="text-text-primary font-mono text-sm mt-1 p-2 bg-muted rounded border">
              {transaction?.id}
            </p>
          </div>

          <div>
            <label className="text-sm font-medium text-text-secondary">Amount</label>
            <p className="text-text-primary text-lg font-semibold mt-1">
              ${transaction?.amount?.toLocaleString()}
            </p>
          </div>

          <div>
            <label className="text-sm font-medium text-text-secondary">Transaction Type</label>
            <div className="flex items-center space-x-2 mt-1">
              <Icon name={getTransactionTypeIcon(transaction?.type)} size={16} />
              <span className="text-text-primary capitalize">
                {transaction?.type?.replace('_', ' ')}
              </span>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-text-secondary">Timestamp</label>
            <p className="text-text-primary mt-1">
              {formatDate(transaction?.timestamp)}
            </p>
          </div>

          <div>
            <label className="text-sm font-medium text-text-secondary">Location</label>
            <div className="flex items-center space-x-2 mt-1">
              <Icon name="MapPin" size={16} color="var(--color-text-secondary)" />
              <span className="text-text-primary">
                {transaction?.location?.city}, {transaction?.location?.country}
              </span>
            </div>
            <p className="text-xs text-text-secondary mt-1">
              Lat: {transaction?.location?.latitude}, Lng: {transaction?.location?.longitude}
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-text-secondary">Sender</label>
            <div className="bg-surface p-3 rounded-lg border border-border mt-1">
              <p className="font-medium text-text-primary">{transaction?.sender?.name}</p>
              <p className="text-sm text-text-secondary">{transaction?.sender?.account}</p>
              <p className="text-xs text-text-secondary mt-1">{transaction?.sender?.bank}</p>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-text-secondary">Receiver</label>
            <div className="bg-surface p-3 rounded-lg border border-border mt-1">
              <p className="font-medium text-text-primary">{transaction?.receiver?.name}</p>
              <p className="text-sm text-text-secondary">{transaction?.receiver?.account}</p>
              <p className="text-xs text-text-secondary mt-1">{transaction?.receiver?.bank}</p>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-text-secondary">Device Information</label>
            <div className="bg-surface p-3 rounded-lg border border-border mt-1">
              <div className="flex items-center space-x-2 mb-1">
                <Icon name="Smartphone" size={14} />
                <span className="text-sm text-text-primary">{transaction?.device?.type}</span>
              </div>
              <p className="text-xs text-text-secondary">IP: {transaction?.device?.ip}</p>
              <p className="text-xs text-text-secondary">OS: {transaction?.device?.os}</p>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-text-secondary">Reference Number</label>
            <p className="text-text-primary font-mono text-sm mt-1 p-2 bg-muted rounded border">
              {transaction?.referenceNumber}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransactionInfo;