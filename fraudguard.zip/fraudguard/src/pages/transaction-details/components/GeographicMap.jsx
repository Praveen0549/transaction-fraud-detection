import React from 'react';
import Icon from '../../../components/AppIcon';

const GeographicMap = ({ transaction }) => {
  const { latitude, longitude, city, country } = transaction?.location;

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <h2 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
        <Icon name="Map" size={20} color="var(--color-primary)" />
        <span>Geographic Analysis</span>
      </h2>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map */}
        <div className="lg:col-span-2">
          <div className="relative w-full h-64 lg:h-80 rounded-lg overflow-hidden border border-border">
            <iframe
              width="100%"
              height="100%"
              loading="lazy"
              title={`${city}, ${country}`}
              referrerPolicy="no-referrer-when-downgrade"
              src={`https://www.google.com/maps?q=${latitude},${longitude}&z=14&output=embed`}
              className="border-0"
            />
            <div className="absolute top-4 left-4 bg-card px-3 py-2 rounded-lg shadow-card border border-border">
              <div className="flex items-center space-x-2">
                <Icon name="MapPin" size={16} color="var(--color-error)" />
                <span className="text-sm font-medium text-text-primary">Transaction Location</span>
              </div>
            </div>
          </div>
        </div>

        {/* Location Details */}
        <div className="space-y-4">
          <div className="bg-surface p-4 rounded-lg border border-border">
            <h4 className="font-medium text-text-primary mb-3 flex items-center space-x-2">
              <Icon name="MapPin" size={16} />
              <span>Location Details</span>
            </h4>
            <div className="space-y-2 text-sm">
              <div>
                <span className="text-text-secondary">City:</span>
                <span className="text-text-primary ml-2 font-medium">{city}</span>
              </div>
              <div>
                <span className="text-text-secondary">Country:</span>
                <span className="text-text-primary ml-2 font-medium">{country}</span>
              </div>
              <div>
                <span className="text-text-secondary">Coordinates:</span>
                <div className="text-text-primary ml-2 font-mono text-xs">
                  <div>{latitude}°N</div>
                  <div>{longitude}°E</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-surface p-4 rounded-lg border border-border">
            <h4 className="font-medium text-text-primary mb-3 flex items-center space-x-2">
              <Icon name="Shield" size={16} />
              <span>Risk Assessment</span>
            </h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-text-secondary">Location Risk</span>
                <span className="text-sm font-medium text-success">Low</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-text-secondary">Known Location</span>
                <div className="flex items-center space-x-1">
                  <Icon name="Check" size={14} color="var(--color-success)" />
                  <span className="text-sm font-medium text-success">Yes</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-text-secondary">Travel Pattern</span>
                <span className="text-sm font-medium text-text-primary">Normal</span>
              </div>
            </div>
          </div>

          <div className="bg-surface p-4 rounded-lg border border-border">
            <h4 className="font-medium text-text-primary mb-3 flex items-center space-x-2">
              <Icon name="Clock" size={16} />
              <span>Time Zone Info</span>
            </h4>
            <div className="space-y-2 text-sm">
              <div>
                <span className="text-text-secondary">Local Time:</span>
                <span className="text-text-primary ml-2 font-medium">
                  {new Date(transaction.timestamp)?.toLocaleString('en-US', {
                    timeZone: transaction?.location?.timezone || 'UTC',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </span>
              </div>
              <div>
                <span className="text-text-secondary">Time Zone:</span>
                <span className="text-text-primary ml-2 font-medium">
                  {transaction?.location?.timezone || 'UTC'}
                </span>
              </div>
              <div>
                <span className="text-text-secondary">Business Hours:</span>
                <div className="flex items-center space-x-1 ml-2">
                  <Icon name="Check" size={14} color="var(--color-success)" />
                  <span className="text-success font-medium">Yes</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GeographicMap;