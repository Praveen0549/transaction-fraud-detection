import React from 'react';
import Icon from '../../../components/AppIcon';

const FraudAnalysis = ({ analysis }) => {
  const getRiskColor = (score) => {
    if (score >= 0.7) return 'text-error';
    if (score >= 0.4) return 'text-warning';
    return 'text-success';
  };

  const getRiskBgColor = (score) => {
    if (score >= 0.7) return 'bg-red-100';
    if (score >= 0.4) return 'bg-yellow-100';
    return 'bg-green-100';
  };

  const getFactorIcon = (factor) => {
    switch (factor?.type) {
      case 'location':
        return 'MapPin';
      case 'time':
        return 'Clock';
      case 'amount':
        return 'DollarSign';
      case 'frequency':
        return 'BarChart3';
      case 'device':
        return 'Smartphone';
      case 'pattern':
        return 'TrendingUp';
      default:
        return 'AlertTriangle';
    }
  };

  const getFactorColor = (impact) => {
    switch (impact) {
      case 'high':
        return 'text-error';
      case 'medium':
        return 'text-warning';
      case 'low':
        return 'text-success';
      default:
        return 'text-text-secondary';
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <h2 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
        <Icon name="Brain" size={20} color="var(--color-primary)" />
        <span>AI Fraud Analysis</span>
      </h2>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Risk Score Visualization */}
        <div className="space-y-4">
          <div className="text-center">
            <div className={`inline-flex items-center justify-center w-24 h-24 rounded-full ${getRiskBgColor(analysis?.fraudProbability)} mb-3`}>
              <span className={`text-2xl font-bold ${getRiskColor(analysis?.fraudProbability)}`}>
                {(analysis?.fraudProbability * 100)?.toFixed(0)}%
              </span>
            </div>
            <p className="text-sm text-text-secondary">Fraud Probability</p>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-text-secondary">Confidence Score</span>
                <span className="text-text-primary font-medium">
                  {(analysis?.confidence * 100)?.toFixed(1)}%
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${analysis?.confidence * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-text-secondary">Model Accuracy</span>
                <span className="text-text-primary font-medium">
                  {(analysis?.modelAccuracy * 100)?.toFixed(1)}%
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-success h-2 rounded-full transition-all duration-300"
                  style={{ width: `${analysis?.modelAccuracy * 100}%` }}
                />
              </div>
            </div>
          </div>

          <div className="bg-surface p-4 rounded-lg border border-border">
            <h4 className="font-medium text-text-primary mb-2">Model Information</h4>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span className="text-text-secondary">Model Version:</span>
                <span className="text-text-primary">{analysis?.modelVersion}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Last Updated:</span>
                <span className="text-text-primary">{analysis?.lastUpdated}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Processing Time:</span>
                <span className="text-text-primary">{analysis?.processingTime}ms</span>
              </div>
            </div>
          </div>
        </div>

        {/* Risk Factors */}
        <div>
          <h4 className="font-medium text-text-primary mb-3">Risk Factors</h4>
          <div className="space-y-3">
            {analysis?.riskFactors?.map((factor, index) => (
              <div key={index} className="bg-surface p-4 rounded-lg border border-border">
                <div className="flex items-start space-x-3">
                  <div className={`p-2 rounded-lg ${factor?.impact === 'high' ? 'bg-red-50' : factor?.impact === 'medium' ? 'bg-yellow-50' : 'bg-green-50'}`}>
                    <Icon 
                      name={getFactorIcon(factor)} 
                      size={16} 
                      color={`var(--color-${factor?.impact === 'high' ? 'error' : factor?.impact === 'medium' ? 'warning' : 'success'})`}
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h5 className="font-medium text-text-primary">{factor?.name}</h5>
                      <span className={`text-xs font-medium px-2 py-1 rounded ${getFactorColor(factor?.impact)} ${factor?.impact === 'high' ? 'bg-red-50' : factor?.impact === 'medium' ? 'bg-yellow-50' : 'bg-green-50'}`}>
                        {factor?.impact?.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm text-text-secondary mb-2">{factor?.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-text-secondary">Impact Score</span>
                      <span className={`text-sm font-medium ${getFactorColor(factor?.impact)}`}>
                        {(factor?.score * 100)?.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Analysis Summary */}
      <div className="mt-6 p-4 bg-surface rounded-lg border border-border">
        <h4 className="font-medium text-text-primary mb-2 flex items-center space-x-2">
          <Icon name="FileText" size={16} />
          <span>Analysis Summary</span>
        </h4>
        <p className="text-sm text-text-secondary leading-relaxed">
          {analysis?.summary}
        </p>
      </div>
    </div>
  );
};

export default FraudAnalysis;