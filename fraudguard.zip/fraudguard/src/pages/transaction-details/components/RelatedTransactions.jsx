import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RelatedTransactions = ({ relatedTransactions, onViewTransaction }) => {
  const [activeTab, setActiveTab] = useState('similar');

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getRiskColor = (probability) => {
    if (probability >= 0.7) return 'text-error';
    if (probability >= 0.4) return 'text-warning';
    return 'text-success';
  };

  const getRiskBg = (probability) => {
    if (probability >= 0.7) return 'bg-red-50';
    if (probability >= 0.4) return 'bg-yellow-50';
    return 'bg-green-50';
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved':
        return 'CheckCircle';
      case 'rejected':
        return 'XCircle';
      case 'pending':
        return 'Clock';
      case 'escalated':
        return 'AlertTriangle';
      default:
        return 'Circle';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved':
        return 'text-success';
      case 'rejected':
        return 'text-error';
      case 'pending':
        return 'text-warning';
      case 'escalated':
        return 'text-accent';
      default:
        return 'text-text-secondary';
    }
  };

  const tabs = [
    { id: 'similar', label: 'Similar Patterns', count: relatedTransactions?.similar?.length || 0 },
    { id: 'sender', label: 'Same Sender', count: relatedTransactions?.sameSender?.length || 0 },
    { id: 'receiver', label: 'Same Receiver', count: relatedTransactions?.sameReceiver?.length || 0 },
    { id: 'location', label: 'Same Location', count: relatedTransactions?.sameLocation?.length || 0 }
  ];

  const getCurrentTransactions = () => {
    return relatedTransactions?.[activeTab] || [];
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <h2 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
        <Icon name="GitBranch" size={20} color="var(--color-primary)" />
        <span>Related Transactions</span>
      </h2>
      {/* Tabs */}
      <div className="flex flex-wrap gap-2 mb-6 border-b border-border">
        {tabs?.map((tab) => (
          <button
            key={tab?.id}
            onClick={() => setActiveTab(tab?.id)}
            className={`flex items-center space-x-2 px-4 py-2 text-sm font-medium rounded-t-lg transition-micro ${
              activeTab === tab?.id
                ? 'bg-primary text-primary-foreground border-b-2 border-primary'
                : 'text-text-secondary hover:text-text-primary hover:bg-muted'
            }`}
          >
            <span>{tab?.label}</span>
            {tab?.count > 0 && (
              <span className={`px-2 py-0.5 text-xs rounded-full ${
                activeTab === tab?.id 
                  ? 'bg-primary-foreground text-primary' 
                  : 'bg-muted text-text-secondary'
              }`}>
                {tab?.count}
              </span>
            )}
          </button>
        ))}
      </div>
      {/* Transaction List */}
      <div className="space-y-3">
        {getCurrentTransactions()?.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="Search" size={48} color="var(--color-text-secondary)" className="mx-auto mb-3 opacity-50" />
            <p className="text-text-secondary">No related transactions found</p>
          </div>
        ) : (
          getCurrentTransactions()?.map((transaction) => (
            <div
              key={transaction?.id}
              className="bg-surface p-4 rounded-lg border border-border hover:shadow-card transition-micro"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${getRiskBg(transaction?.fraudProbability)}`}>
                    <Icon 
                      name="ArrowRightLeft" 
                      size={16} 
                      color={`var(--color-${transaction?.fraudProbability >= 0.7 ? 'error' : transaction?.fraudProbability >= 0.4 ? 'warning' : 'success'})`}
                    />
                  </div>
                  <div>
                    <p className="font-medium text-text-primary">
                      ${transaction?.amount?.toLocaleString()}
                    </p>
                    <p className="text-sm text-text-secondary">
                      {formatDate(transaction?.timestamp)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <div className="text-right">
                    <p className={`text-sm font-medium ${getRiskColor(transaction?.fraudProbability)}`}>
                      {(transaction?.fraudProbability * 100)?.toFixed(1)}% Risk
                    </p>
                    <div className="flex items-center space-x-1">
                      <Icon 
                        name={getStatusIcon(transaction?.status)} 
                        size={14} 
                        color={`var(--color-${transaction?.status === 'approved' ? 'success' : transaction?.status === 'rejected' ? 'error' : transaction?.status === 'pending' ? 'warning' : 'accent'})`}
                      />
                      <span className={`text-xs ${getStatusColor(transaction?.status)}`}>
                        {transaction?.status?.charAt(0)?.toUpperCase() + transaction?.status?.slice(1)}
                      </span>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    iconName="ExternalLink"
                    iconPosition="right"
                    onClick={() => onViewTransaction(transaction?.id)}
                  >
                    View
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <span className="text-text-secondary">From:</span>
                  <p className="text-text-primary font-medium truncate">
                    {transaction?.sender?.name}
                  </p>
                </div>
                <div>
                  <span className="text-text-secondary">To:</span>
                  <p className="text-text-primary font-medium truncate">
                    {transaction?.receiver?.name}
                  </p>
                </div>
                <div>
                  <span className="text-text-secondary">Type:</span>
                  <p className="text-text-primary font-medium capitalize">
                    {transaction?.type?.replace('_', ' ')}
                  </p>
                </div>
                <div>
                  <span className="text-text-secondary">Location:</span>
                  <p className="text-text-primary font-medium">
                    {transaction?.location?.city}
                  </p>
                </div>
              </div>

              {/* Similarity Score */}
              {transaction?.similarityScore && (
                <div className="mt-3 pt-3 border-t border-border">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">Similarity Score</span>
                    <span className="text-sm font-medium text-primary">
                      {(transaction?.similarityScore * 100)?.toFixed(0)}%
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5 mt-1">
                    <div 
                      className="bg-primary h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${transaction?.similarityScore * 100}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
      {getCurrentTransactions()?.length > 0 && (
        <div className="mt-4 text-center">
          <Button variant="outline" iconName="MoreHorizontal">
            Load More Transactions
          </Button>
        </div>
      )}
    </div>
  );
};

export default RelatedTransactions;