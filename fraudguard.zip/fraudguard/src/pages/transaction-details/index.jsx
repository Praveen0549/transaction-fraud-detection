import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Header from '../../components/ui/Header';
import TransactionHeader from './components/TransactionHeader';
import TransactionInfo from './components/TransactionInfo';
import FraudAnalysis from './components/FraudAnalysis';
import GeographicMap from './components/GeographicMap';
import RelatedTransactions from './components/RelatedTransactions';
import CommentsSection from './components/CommentsSection';
import ActionModal from './components/ActionModal';

const TransactionDetails = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const transactionId = searchParams?.get('id') || 'TXN-2024-001';
  
  const [transaction, setTransaction] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [relatedTransactions, setRelatedTransactions] = useState({});
  const [comments, setComments] = useState([]);
  const [actionModal, setActionModal] = useState({ isOpen: false, action: null });
  const [loading, setLoading] = useState(true);

  // Mock transaction data
  const mockTransaction = {
    id: transactionId,
    amount: 15750.00,
    timestamp: "2024-09-09T14:30:15.000Z",
    type: "upi",
    status: "pending",
    riskLevel: "high",
    fraudProbability: 0.85,
    processingTime: 245,
    referenceNumber: "UPI240909143015",
    sender: {
      name: "Rajesh Kumar",
      account: "****1234",
      bank: "State Bank of India",
      phone: "+91-9876543210"
    },
    receiver: {
      name: "Tech Solutions Pvt Ltd",
      account: "****5678",
      bank: "HDFC Bank",
      phone: "+91-9123456789"
    },
    location: {
      city: "Mumbai",
      country: "India",
      latitude: 19.0760,
      longitude: 72.8777,
      timezone: "Asia/Kolkata"
    },
    device: {
      type: "Android Mobile",
      ip: "192.168.1.105",
      os: "Android 13"
    }
  };

  const mockAnalysis = {
    fraudProbability: 0.85,
    confidence: 0.92,
    modelAccuracy: 0.94,
    modelVersion: "v2.3.1",
    lastUpdated: "2024-09-08",
    processingTime: 245,
    summary: `High-risk transaction detected due to unusual amount pattern, new receiver relationship, and transaction timing outside normal business hours. The AI model identified multiple risk factors including geographic inconsistencies and device fingerprint anomalies. Immediate manual review recommended.`,
    riskFactors: [
      {
        name: "Unusual Amount Pattern",
        type: "amount",
        description: "Transaction amount significantly higher than sender's typical transaction pattern",
        score: 0.89,
        impact: "high"
      },
      {
        name: "New Receiver Relationship",
        type: "pattern",
        description: "First-time transaction to this receiver account",
        score: 0.76,
        impact: "medium"
      },
      {
        name: "Off-Hours Transaction",
        type: "time",
        description: "Transaction initiated outside normal business hours",
        score: 0.65,
        impact: "medium"
      },
      {
        name: "Geographic Inconsistency",
        type: "location",
        description: "Transaction location differs from sender's usual geographic pattern",
        score: 0.72,
        impact: "high"
      },
      {
        name: "Device Fingerprint Anomaly",
        type: "device",
        description: "Unusual device characteristics detected",
        score: 0.58,
        impact: "low"
      }
    ]
  };

  const mockRelatedTransactions = {
    similar: [
      {
        id: "TXN-2024-002",
        amount: 14200.00,
        timestamp: "2024-09-08T16:45:22.000Z",
        type: "upi",
        status: "rejected",
        fraudProbability: 0.91,
        similarityScore: 0.87,
        sender: { name: "Rajesh Kumar" },
        receiver: { name: "Digital Services Ltd" },
        location: { city: "Mumbai" }
      },
      {
        id: "TXN-2024-003",
        amount: 16800.00,
        timestamp: "2024-09-07T19:20:10.000Z",
        type: "upi",
        status: "escalated",
        fraudProbability: 0.78,
        similarityScore: 0.82,
        sender: { name: "Rajesh Kumar" },
        receiver: { name: "Online Tech Hub" },
        location: { city: "Mumbai" }
      }
    ],
    sameSender: [
      {
        id: "TXN-2024-004",
        amount: 2500.00,
        timestamp: "2024-09-06T10:15:30.000Z",
        type: "upi",
        status: "approved",
        fraudProbability: 0.12,
        sender: { name: "Rajesh Kumar" },
        receiver: { name: "Grocery Store" },
        location: { city: "Mumbai" }
      }
    ],
    sameReceiver: [],
    sameLocation: [
      {
        id: "TXN-2024-005",
        amount: 8900.00,
        timestamp: "2024-09-09T12:30:45.000Z",
        type: "card",
        status: "pending",
        fraudProbability: 0.45,
        sender: { name: "Priya Sharma" },
        receiver: { name: "Tech Solutions Pvt Ltd" },
        location: { city: "Mumbai" }
      }
    ]
  };

  const mockComments = [
    {
      id: 1,
      user: {
        name: "Sarah Johnson",
        role: "analyst",
        avatar: "https://randomuser.me/api/portraits/women/32.jpg"
      },
      content: "Initial analysis shows multiple red flags. The transaction amount is 300% higher than the sender\'s average transaction value. Recommending immediate hold for further investigation.",
      timestamp: "2024-09-09T14:35:20.000Z",
      actions: [
        {
          type: "hold",
          description: "Transaction placed on hold pending investigation"
        }
      ]
    },
    {
      id: 2,
      user: {
        name: "System",
        role: "system"
      },
      content: "Automated risk assessment completed. High-risk score of 85% triggered manual review workflow.",
      timestamp: "2024-09-09T14:30:45.000Z"
    },
    {
      id: 3,
      user: {
        name: "Mike Wilson",
        role: "admin",
        avatar: "https://randomuser.me/api/portraits/men/45.jpg"
      },
      content: "Cross-referencing with recent fraud patterns. Similar MO detected in 3 other cases this week. Escalating to fraud investigation team.",
      timestamp: "2024-09-09T15:10:15.000Z",
      actions: [
        {
          type: "escalate",
          description: "Case escalated to fraud investigation team"
        }
      ]
    }
  ];

  useEffect(() => {
    // Simulate API loading
    const loadTransactionData = async () => {
      setLoading(true);
      
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setTransaction(mockTransaction);
      setAnalysis(mockAnalysis);
      setRelatedTransactions(mockRelatedTransactions);
      setComments(mockComments);
      setLoading(false);
    };

    loadTransactionData();
  }, [transactionId]);

  const handleBack = () => {
    navigate('/user-dashboard');
  };

  const handleAction = (action) => {
    setActionModal({ isOpen: true, action });
  };

  const handleActionConfirm = async (actionData) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Update transaction status
    setTransaction(prev => ({
      ...prev,
      status: actionData?.action === 'escalate' ? 'escalated' : actionData?.action === 'approve' ? 'approved' : 'rejected'
    }));

    // Add system comment
    const newComment = {
      id: comments?.length + 1,
      user: {
        name: "System",
        role: "system"
      },
      content: `Transaction ${actionData?.action}d: ${actionData?.justification}`,
      timestamp: new Date()?.toISOString(),
      actions: [
        {
          type: actionData?.action,
          description: `Transaction ${actionData?.action}d by analyst`
        }
      ]
    };

    setComments(prev => [newComment, ...prev]);
  };

  const handleAddComment = async (content) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newComment = {
      id: comments?.length + 1,
      user: {
        name: "Current User",
        role: "analyst",
        avatar: "https://randomuser.me/api/portraits/men/25.jpg"
      },
      content,
      timestamp: new Date()?.toISOString()
    };

    setComments(prev => [newComment, ...prev]);
  };

  const handleViewTransaction = (id) => {
    navigate(`/transaction-details?id=${id}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole="analyst" />
        <div className="pt-16 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-text-secondary">Loading transaction details...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!transaction) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole="analyst" />
        <div className="pt-16 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <p className="text-text-primary text-lg mb-2">Transaction not found</p>
            <p className="text-text-secondary mb-4">The requested transaction could not be loaded.</p>
            <button
              onClick={handleBack}
              className="text-primary hover:underline"
            >
              Return to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header userRole="analyst" alertCount={3} />
      <div className="pt-16">
        <TransactionHeader
          transaction={transaction}
          onBack={handleBack}
          onApprove={() => handleAction('approve')}
          onReject={() => handleAction('reject')}
          onEscalate={() => handleAction('escalate')}
        />

        <div className="max-w-7xl mx-auto p-6 space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            <div className="xl:col-span-2 space-y-6">
              <TransactionInfo transaction={transaction} />
              <FraudAnalysis analysis={analysis} />
              <GeographicMap transaction={transaction} />
            </div>
            
            <div className="space-y-6">
              <RelatedTransactions
                relatedTransactions={relatedTransactions}
                onViewTransaction={handleViewTransaction}
              />
              <CommentsSection
                comments={comments}
                onAddComment={handleAddComment}
              />
            </div>
          </div>
        </div>
      </div>
      <ActionModal
        isOpen={actionModal?.isOpen}
        onClose={() => setActionModal({ isOpen: false, action: null })}
        action={actionModal?.action}
        transaction={transaction}
        onConfirm={handleActionConfirm}
      />
    </div>
  );
};

export default TransactionDetails;