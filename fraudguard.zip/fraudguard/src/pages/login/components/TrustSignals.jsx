import React from 'react';
import Icon from '../../../components/AppIcon';

const TrustSignals = () => {
  const securityFeatures = [
    {
      icon: 'Shield',
      title: 'SSL Encrypted',
      description: '256-bit encryption'
    },
    {
      icon: 'Lock',
      title: 'Bank-Grade Security',
      description: 'PCI DSS compliant'
    },
    {
      icon: 'CheckCircle',
      title: 'SOC 2 Certified',
      description: 'Audited security controls'
    },
    {
      icon: 'Eye',
      title: 'Privacy Protected',
      description: 'GDPR compliant'
    }
  ];

  const certifications = [
    'ISO 27001',
    'PCI DSS Level 1',
    'SOC 2 Type II',
    'GDPR Compliant'
  ];

  return (
    <div className="space-y-6">
      {/* Security Features Grid */}
      <div className="grid grid-cols-2 gap-4">
        {securityFeatures?.map((feature, index) => (
          <div
            key={index}
            className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg border border-border/50"
          >
            <div className="flex items-center justify-center w-8 h-8 bg-success/10 rounded-full">
              <Icon name={feature?.icon} size={16} color="var(--color-success)" />
            </div>
            <div>
              <p className="text-xs font-medium text-text-primary">
                {feature?.title}
              </p>
              <p className="text-xs text-text-secondary">
                {feature?.description}
              </p>
            </div>
          </div>
        ))}
      </div>
      {/* Compliance Badges */}
      <div className="space-y-3">
        <p className="text-xs font-medium text-text-primary text-center">
          Trusted by financial institutions worldwide
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          {certifications?.map((cert, index) => (
            <span
              key={index}
              className="px-2 py-1 text-xs font-medium text-text-secondary bg-surface border border-border rounded-md"
            >
              {cert}
            </span>
          ))}
        </div>
      </div>
      {/* Security Notice */}
      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start space-x-2">
          <Icon name="Info" size={14} color="var(--color-primary)" className="mt-0.5" />
          <div>
            <p className="text-xs font-medium text-blue-900">
              Secure Connection Active
            </p>
            <p className="text-xs text-blue-700 mt-1">
              Your data is protected with end-to-end encryption and never stored in plain text.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrustSignals;