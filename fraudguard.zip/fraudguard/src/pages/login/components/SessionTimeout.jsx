import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SessionTimeout = ({ isVisible, onExtend, onLogout }) => {
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes in seconds

  useEffect(() => {
    if (!isVisible) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          onLogout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isVisible, onLogout]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-surface rounded-xl shadow-modal max-w-md w-full p-6 space-y-4">
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-10 h-10 bg-warning/10 rounded-full">
            <Icon name="Clock" size={20} color="var(--color-warning)" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-text-primary">
              Session Timeout Warning
            </h3>
            <p className="text-sm text-text-secondary">
              Your session will expire in {formatTime(timeLeft)}
            </p>
          </div>
        </div>

        <p className="text-sm text-text-secondary">
          For your security, you'll be automatically logged out due to inactivity. 
          Click "Stay Signed In" to extend your session.
        </p>

        <div className="flex space-x-3">
          <Button
            variant="outline"
            onClick={onLogout}
            className="flex-1"
          >
            Sign Out Now
          </Button>
          <Button
            variant="default"
            onClick={onExtend}
            className="flex-1"
            iconName="RefreshCw"
            iconPosition="left"
          >
            Stay Signed In
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SessionTimeout;