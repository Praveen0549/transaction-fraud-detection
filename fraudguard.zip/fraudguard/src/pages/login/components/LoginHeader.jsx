import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const LoginHeader = () => {
  return (
    <div className="text-center space-y-6">
      {/* Logo */}
      <Link to="/user-dashboard" className="inline-flex items-center space-x-3">
        <div className="flex items-center justify-center w-12 h-12 bg-primary rounded-xl shadow-card">
          <Icon name="Shield" size={24} color="white" />
        </div>
        <span className="text-2xl font-bold text-text-primary">
          FraudGuard
        </span>
      </Link>

      {/* Welcome Message */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-text-primary">
          Welcome Back
        </h1>
        <p className="text-text-secondary max-w-md mx-auto">
          Sign in to your FraudGuard account to access real-time fraud detection and transaction monitoring tools.
        </p>
      </div>

      {/* System Status */}
      <div className="inline-flex items-center space-x-2 px-3 py-1 bg-success/10 border border-success/20 rounded-full">
        <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
        <span className="text-xs font-medium text-success">
          All systems operational
        </span>
      </div>
    </div>
  );
};

export default LoginHeader;