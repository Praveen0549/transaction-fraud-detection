import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import TrustSignals from './components/TrustSignals';
import LoginHeader from './components/LoginHeader';
import SessionTimeout from './components/SessionTimeout';

const LoginPage = () => {
  const navigate = useNavigate();
  const [showSessionTimeout, setShowSessionTimeout] = useState(false);

  useEffect(() => {
    // Check if user is already authenticated
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (isAuthenticated === 'true') {
      navigate('/user-dashboard');
    }

    // Simulate session timeout warning for demo purposes
    const timeoutTimer = setTimeout(() => {
      setShowSessionTimeout(true);
    }, 30000); // Show after 30 seconds for demo

    return () => clearTimeout(timeoutTimer);
  }, [navigate]);

  const handleExtendSession = () => {
    setShowSessionTimeout(false);
    // In a real app, this would refresh the session token
  };

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('userRole');
    localStorage.removeItem('userEmail');
    setShowSessionTimeout(false);
    // User is already on login page, so just hide the modal
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-gray-50">
      <div className="flex min-h-screen">
        {/* Left Side - Login Form */}
        <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
          <div className="w-full max-w-md space-y-8">
            <LoginHeader />
            <LoginForm />
          </div>
        </div>

        {/* Right Side - Trust Signals & Security Info */}
        <div className="hidden lg:flex lg:flex-1 bg-gradient-to-br from-primary/5 to-primary/10 items-center justify-center p-12">
          <div className="w-full max-w-lg space-y-8">
            {/* Hero Section */}
            <div className="text-center space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-2xl">
                <div className="flex items-center justify-center w-12 h-12 bg-primary rounded-xl">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.031 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
              </div>
              <h2 className="text-2xl font-bold text-text-primary">
                Enterprise-Grade Security
              </h2>
              <p className="text-text-secondary">
                Protecting financial institutions with advanced fraud detection and real-time monitoring capabilities.
              </p>
            </div>

            {/* Trust Signals */}
            <TrustSignals />

            {/* Statistics */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-border/50">
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">99.9%</p>
                <p className="text-xs text-text-secondary">Uptime</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">24/7</p>
                <p className="text-xs text-text-secondary">Monitoring</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">500+</p>
                <p className="text-xs text-text-secondary">Banks Trust Us</p>
              </div>
            </div>

            {/* Footer Note */}
            <div className="text-center pt-6">
              <p className="text-xs text-text-secondary">
                © {new Date()?.getFullYear()} FraudGuard. All rights reserved.
                <br />
                Protecting your financial transactions with AI-powered security.
              </p>
            </div>
          </div>
        </div>
      </div>
      {/* Session Timeout Modal */}
      <SessionTimeout
        isVisible={showSessionTimeout}
        onExtend={handleExtendSession}
        onLogout={handleLogout}
      />
    </div>
  );
};

export default LoginPage;