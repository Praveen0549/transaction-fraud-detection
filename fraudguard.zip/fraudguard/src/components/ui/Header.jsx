import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = ({ userRole = 'customer', alertCount = 0, isOnline = true }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const navigationItems = [
    {
      label: 'Dashboard',
      path: '/user-dashboard',
      icon: 'LayoutDashboard',
      roles: ['customer', 'analyst', 'admin'],
      badge: alertCount > 0 ? alertCount : null
    },
    {
      label: 'Transactions',
      path: '/transaction-input',
      icon: 'CreditCard',
      roles: ['analyst', 'admin']
    },
    {
      label: 'Reports',
      path: '/reports',
      icon: 'FileText',
      roles: ['analyst', 'admin']
    }
  ];

  const filteredNavigation = navigationItems?.filter(item => 
    item?.roles?.includes(userRole)
  );

  const isActivePath = (path) => {
    if (path === '/user-dashboard') {
      return location?.pathname === path;
    }
    if (path === '/transaction-input') {
      return location?.pathname === path || location?.pathname === '/transaction-details';
    }
    return location?.pathname === path;
  };

  const getRoleDisplayName = (role) => {
    const roleMap = {
      customer: 'Customer',
      analyst: 'Analyst',
      admin: 'Administrator'
    };
    return roleMap?.[role] || 'User';
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-surface border-b border-border">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between h-16 px-4 lg:px-6">
          {/* Logo */}
          <Link to="/user-dashboard" className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
              <Icon name="Shield" size={20} color="white" />
            </div>
            <span className="text-xl font-semibold text-text-primary">
              FraudGuard
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            {filteredNavigation?.map((item) => (
              <Link
                key={item?.path}
                to={item?.path}
                className={`relative flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-micro ${
                  isActivePath(item?.path)
                    ? 'bg-primary text-primary-foreground'
                    : 'text-text-secondary hover:text-text-primary hover:bg-muted'
                }`}
              >
                <Icon name={item?.icon} size={18} />
                <span>{item?.label}</span>
                {item?.badge && (
                  <span className="absolute -top-1 -right-1 flex items-center justify-center w-5 h-5 text-xs font-medium text-white bg-error rounded-full">
                    {item?.badge > 99 ? '99+' : item?.badge}
                  </span>
                )}
              </Link>
            ))}
          </nav>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            {/* System Status Indicator */}
            <div className="hidden lg:flex items-center space-x-2 text-xs text-text-secondary">
              <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-success animate-pulse' : 'bg-error'}`} />
              <span>{isOnline ? 'Online' : 'Offline'}</span>
            </div>

            {/* User Role Indicator */}
            <div className="hidden md:flex items-center space-x-2 px-3 py-1 bg-muted rounded-lg">
              <Icon name="User" size={16} color="var(--color-text-secondary)" />
              <span className="text-sm font-medium text-text-secondary">
                {getRoleDisplayName(userRole)}
              </span>
            </div>

            {/* Quick Actions */}
            <div className="hidden lg:flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                iconName="Search"
                iconPosition="left"
                className="text-text-secondary hover:text-text-primary"
              >
                Search
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMobileMenu}
              className="md:hidden"
            >
              <Icon name={isMobileMenuOpen ? "X" : "Menu"} size={20} />
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-surface border-t border-border">
            <nav className="px-4 py-4 space-y-2">
              {filteredNavigation?.map((item) => (
                <Link
                  key={item?.path}
                  to={item?.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`relative flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-micro ${
                    isActivePath(item?.path)
                      ? 'bg-primary text-primary-foreground'
                      : 'text-text-secondary hover:text-text-primary hover:bg-muted'
                  }`}
                >
                  <Icon name={item?.icon} size={20} />
                  <span>{item?.label}</span>
                  {item?.badge && (
                    <span className="ml-auto flex items-center justify-center w-6 h-6 text-xs font-medium text-white bg-error rounded-full">
                      {item?.badge > 99 ? '99+' : item?.badge}
                    </span>
                  )}
                </Link>
              ))}
              
              {/* Mobile System Status */}
              <div className="flex items-center justify-between px-4 py-3 mt-4 border-t border-border">
                <div className="flex items-center space-x-2">
                  <Icon name="User" size={16} color="var(--color-text-secondary)" />
                  <span className="text-sm text-text-secondary">
                    {getRoleDisplayName(userRole)}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-success animate-pulse' : 'bg-error'}`} />
                  <span className="text-xs text-text-secondary">
                    {isOnline ? 'Online' : 'Offline'}
                  </span>
                </div>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;