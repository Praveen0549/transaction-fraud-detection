import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import TransactionDetails from './pages/transaction-details';
import LoginPage from './pages/login';
import TransactionInput from './pages/transaction-input';
import UserDashboard from './pages/user-dashboard';
import Reports from './pages/reports';
import Register from './pages/register';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<LoginPage />} />
        <Route path="/transaction-details" element={<TransactionDetails />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/transaction-input" element={<TransactionInput />} />
        <Route path="/user-dashboard" element={<UserDashboard />} />
        <Route path="/reports" element={<Reports />} />
        <Route path="/register" element={<Register />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
